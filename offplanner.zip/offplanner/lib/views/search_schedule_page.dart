// lib/views/search_schedule_page.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:offplanner/providers/schedule_provider.dart';
import 'package:offplanner/models/schedule_item.dart';
import 'package:offplanner/widgets/schedule_edit_sheet.dart';

class SearchSchedulePage extends StatefulWidget {
  const SearchSchedulePage({super.key});

  @override
  State<SearchSchedulePage> createState() => _SearchSchedulePageState();
}

class _SearchSchedulePageState extends State<SearchSchedulePage> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final scheduleProv = context.watch<ScheduleProvider>();

    final List<ScheduleItem> results = _query.trim().isEmpty
        ? const []
        : scheduleProv.searchByKeyword(_query);

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: TextField(
          autofocus: true,
          decoration: const InputDecoration(
            hintText: '일정 제목 또는 메모 검색',
            border: InputBorder.none,
          ),
          onChanged: (value) {
            setState(() {
              _query = value;
            });
          },
        ),
      ),
      body: _buildBody(context, results),
    );
  }

  Widget _buildBody(BuildContext context, List<ScheduleItem> results) {
    if (_query.trim().isEmpty) {
      return const Center(
        child: Text(
          '검색어를 입력해 주세요.',
          style: TextStyle(fontSize: 14),
        ),
      );
    }

    if (results.isEmpty) {
      return const Center(
        child: Text(
          '검색된 일정이 없습니다.',
          style: TextStyle(fontSize: 14),
        ),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      itemCount: results.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (context, index) {
        final item = results[index];
        return _buildResultTile(context, item);
      },
    );
  }

  Widget _buildResultTile(BuildContext context, ScheduleItem item) {
    final dateLabel = _formatDateLabel(item);
    final timeLabel = '${item.start.format()} ~ ${item.end.format()}';
    final color = _colorFromHex(item.colorHex);

    return ListTile(
      leading: Container(
        width: 10,
        height: 10,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
        ),
      ),
      title: Text(
        item.title,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      subtitle: Text(
        '$dateLabel  ·  $timeLabel',
        style: const TextStyle(fontSize: 12),
      ),
      onTap: () => _openEditSheet(context, item),
      trailing: IconButton(
        icon: const Icon(Icons.delete_outline),
        onPressed: () => _confirmDelete(context, item),
      ),
    );
  }

  void _openEditSheet(BuildContext context, ScheduleItem item) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => ScheduleEditSheet(existing: item),
    );
  }

  Future<void> _confirmDelete(
      BuildContext context, ScheduleItem item) async {
    final scheduleProv = context.read<ScheduleProvider>();

    final ok = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('일정 삭제'),
            content: Text('"${item.title}" 일정을 삭제할까요?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(false),
                child: const Text('취소'),
              ),
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(true),
                child: const Text(
                  '삭제',
                  style: TextStyle(color: Colors.red),
                ),
              ),
            ],
          ),
        ) ??
        false;

    if (!ok) return;

    await scheduleProv.deleteSchedule(item.id);
  
  }

  String _formatDateLabel(ScheduleItem item) {
    final d = item.date;
    return '${d.year}.${d.month.toString().padLeft(2, '0')}.${d.day.toString().padLeft(2, '0')}';
  }

  Color _colorFromHex(String hex) {
    var h = hex.replaceAll('#', '');
    if (h.length == 6) {
      h = 'FF$h'; 
    final value = int.parse(h, radix: 16);
    return Color(value);
  }
}
