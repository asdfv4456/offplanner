// lib/views/dday_manage_page.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:offplanner/models/dday_item.dart';
import 'package:offplanner/providers/dday_provider.dart';

class DDayManagePage extends StatelessWidget {
  const DDayManagePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('D-Day 관리'),
      ),
      body: Consumer<DDayProvider>(
        builder: (context, ddayProv, _) {
          final items = [...ddayProv.allItems];
          items.sort((a, b) => a.targetDate.compareTo(b.targetDate));

          if (items.isEmpty) {
            return const Center(
              child: Text(
                '등록된 D-Day가 없습니다.\n오른쪽 아래 + 버튼으로 추가하세요.',
                textAlign: TextAlign.center,
              ),
            );
          }

          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, index) {
              final d = items[index];
              final diff = ddayProv.calcDiff(d.targetDate);
              final dText = diff == 0
                  ? 'D-Day'
                  : (diff > 0 ? 'D-$diff' : 'D+${diff.abs()}');

              return ListTile(
                leading: Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    color: _colorFromHex(d.colorHex),
                    shape: BoxShape.circle,
                  ),
                ),
                title: Text(d.title),
                subtitle: Text(
                  '${_formatDate(d.targetDate)} · $dText',
                  style: const TextStyle(fontSize: 12),
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Switch(
                      value: d.isActive,
                      onChanged: (v) {
                        ddayProv.toggleActive(d.id, v);
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.edit, size: 20),
                      onPressed: () {
                        _showEditDialog(context, d);
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, size: 20),
                      onPressed: () async {
                        final ok = await _confirmDelete(context);
                        if (ok) {
                          ddayProv.removeDDay(d.id);
                        }
                      },
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showEditDialog(context, null),
        child: const Icon(Icons.add),
      ),
    );
  }

  String _formatDate(DateTime d) {
    return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  }

  Color _colorFromHex(String hex) {
    final buffer = StringBuffer();
    if (hex.length == 7 && hex.startsWith('#')) {
      buffer.write('ff');
      buffer.write(hex.replaceFirst('#', ''));
    } else if (hex.length == 9 && hex.startsWith('#')) {
      buffer.write(hex.replaceFirst('#', ''));
    } else {
      buffer.write('ff2196f3');
    }
    return Color(int.parse(buffer.toString(), radix: 16));
  }

  Future<bool> _confirmDelete(BuildContext context) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('삭제 확인'),
          content: const Text('이 D-Day를 삭제할까요?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('취소'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('삭제'),
            ),
          ],
        );
      },
    );
    return result ?? false;
  }

  void _showEditDialog(BuildContext context, DDayItem? existing) {
    final isEdit = existing != null;
    final titleController =
        TextEditingController(text: existing?.title ?? '');
    DateTime selectedDate =
        existing?.targetDate ?? DateTime.now();
    String selectedColor =
        existing?.colorHex ?? '#ff2196f3';

    showDialog(
      context: context,
      builder: (context) {
        final ddayProv = context.read<DDayProvider>();

        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: Text(isEdit ? 'D-Day 수정' : 'D-Day 추가'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextField(
                      controller: titleController,
                      decoration: const InputDecoration(
                        labelText: '제목',
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        const Text('날짜: '),
                        TextButton(
                          onPressed: () async {
                            final picked = await showDatePicker(
                              context: context,
                              initialDate: selectedDate,
                              firstDate: DateTime(2000),
                              lastDate: DateTime(2100),
                            );
                            if (picked != null) {
                              setState(() {
                                selectedDate = picked;
                              });
                            }
                          },
                          child: Text(_formatDate(selectedDate)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    const Text('색상 선택'),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      children: [
                        '#ff2196f3', // 파랑
                        '#ff4caf50', // 초록
                        '#ffff9800', // 주황
                        '#fff44336', // 빨강
                        '#ff9c27b0', // 보라
                      ].map((hex) {
                        final color = _colorFromHex(hex);
                        final selected = (hex == selectedColor);
                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              selectedColor = hex;
                            });
                          },
                          child: Container(
                            width: selected ? 28 : 24,
                            height: selected ? 28 : 24,
                            decoration: BoxDecoration(
                              color: color,
                              shape: BoxShape.circle,
                              border: selected
                                  ? Border.all(
                                      color: Colors.black,
                                      width: 2,
                                    )
                                  : null,
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('취소'),
                ),
                TextButton(
                  onPressed: () {
                    final title = titleController.text.trim();
                    if (title.isEmpty) return;

                    if (isEdit) {
                      final updated = existing!.copyWith(
                        title: title,
                        targetDate: selectedDate,
                        colorHex: selectedColor,
                      );
                      ddayProv.updateDDay(updated);
                    } else {
                      final newItem = DDayItem(
                        id: 'manual_${DateTime.now().millisecondsSinceEpoch}',
                        title: title,
                        targetDate: selectedDate,
                        colorHex: selectedColor,
                      );
                      ddayProv.addDDay(newItem);
                    }

                    Navigator.of(context).pop();
                  },
                  child: Text(isEdit ? '수정' : '추가'),
                ),
              ],
            );
          },
        );
      },
    );
  }
}
