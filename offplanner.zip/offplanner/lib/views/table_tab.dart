// lib/views/table_tab.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:offplanner/providers/selected_date_provider.dart';
import 'package:offplanner/providers/schedule_provider.dart';
import 'package:offplanner/models/schedule_item.dart';
import 'package:offplanner/widgets/schedule_edit_sheet.dart';

class TableTab extends StatelessWidget {
  const TableTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer2<SelectedDateProvider, ScheduleProvider>(
      builder: (context, selectedDateProv, scheduleProv, child) {
        final date = selectedDateProv.selectedDate;

        final List<ScheduleItem> schedules =
            List.of(scheduleProv.itemsForDate(date))
              ..sort((a, b) =>
                  a.start.totalMinutes.compareTo(b.start.totalMinutes));

        final textColor = Theme.of(context).colorScheme.onSurface;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () {
                      selectedDateProv.setDate(
                        date.subtract(const Duration(days: 1)),
                      );
                    },
                    icon: Icon(Icons.chevron_left, color: textColor),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${date.year}년 ${date.month}월 ${date.day}일',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: textColor,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          _weekdayKorean(date),
                          style: TextStyle(
                            fontSize: 12,
                            color: textColor.withOpacity(0.7),
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () {
                      selectedDateProv.setDate(
                        date.add(const Duration(days: 1)),
                      );
                    },
                    icon: Icon(Icons.chevron_right, color: textColor),
                  ),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                '이 날의 일정을 표 형태로 정리해서 보여줍니다.\n일정을 탭하면 수정할 수 있어요.',
                style: TextStyle(
                  fontSize: 12,
                  color: textColor.withOpacity(0.7),
                ),
              ),
            ),

            const SizedBox(height: 8),

      
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 8),
              decoration: BoxDecoration(
                color: Colors.white, 
                borderRadius: BorderRadius.circular(6),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: const Row(
                children: [
                  Expanded(
                    flex: 3,
                    child: Text(
                      '제목',
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        color: Colors.black, 
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      '시간',
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        color: Colors.black, 
                      ),
                      textAlign: TextAlign.right,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 4),


            Expanded(
              child: schedules.isEmpty
                  ? Center(
                      child: Text(
                        '이 날의 일정이 없습니다.\n오른쪽 아래 + 버튼으로 일정을 추가해 보세요.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 12,
                          color: textColor.withOpacity(0.6),
                        ),
                      ),
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(8, 4, 8, 16),
                      itemCount: schedules.length,
                      separatorBuilder: (_, __) =>
                          const SizedBox(height: 4),
                      itemBuilder: (context, index) {
                        return _TableRowItem(item: schedules[index]);
                      },
                    ),
            ),
          ],
        );
      },
    );
  }

  String _weekdayKorean(DateTime date) {
    const names = ['월요일', '화요일', '수요일', '목요일', '금요일', '토요일', '일요일'];
    return names[date.weekday - 1];
  }
}


class _TableRowItem extends StatelessWidget {
  final ScheduleItem item;

  const _TableRowItem({required this.item});

  @override
  Widget build(BuildContext context) {
    final scheduleProv = context.read<ScheduleProvider>();

    return Dismissible(
      key: ValueKey(item.id),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 16),
        color: Colors.red.withOpacity(0.85),
        child: const Icon(Icons.delete, color: Colors.white),
      ),
      onDismissed: (_) => scheduleProv.deleteSchedule(item.id),
      child: InkWell(
        onTap: () {
          showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            showDragHandle: true,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
            ),
            builder: (ctx) => ScheduleEditSheet(existing: item),
          );
        },
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(6),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.06),
                blurRadius: 3,
                offset: const Offset(0, 1),
              ),
            ],
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(
            children: [

              Container(
                width: 4,
                height: 30,
                margin: const EdgeInsets.only(right: 12),
                decoration: BoxDecoration(
                  color: _colorFromHex(item.colorHex),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),


              Expanded(
                flex: 3,
                child: Text(
                  item.title,
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.black, 
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),

              Expanded(
                flex: 2,
                child: Text(
                  '${item.start.format()} ~ ${item.end.format()}',
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.black87, 
                  ),
                  textAlign: TextAlign.right,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _colorFromHex(String hex) {
    final buffer = StringBuffer();
    if (hex.length == 7 && hex.startsWith('#')) {
      buffer.write('ff');
      buffer.write(hex.substring(1));
    } else if (hex.length == 9 && hex.startsWith('#')) {
      buffer.write(hex.substring(1));
    } else {
      buffer.write('ff4ecdc4');
    }
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}
