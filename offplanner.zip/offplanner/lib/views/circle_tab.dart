// lib/views/circle_tab.dart
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:offplanner/providers/selected_date_provider.dart';
import 'package:offplanner/providers/schedule_provider.dart';
import 'package:offplanner/models/schedule_item.dart';
import 'package:offplanner/widgets/schedule_edit_sheet.dart';
import 'package:offplanner/views/search_schedule_page.dart';

class CircleTab extends StatelessWidget {
  const CircleTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer2<SelectedDateProvider, ScheduleProvider>(
      builder: (context, selectedDateProv, scheduleProv, child) {
        final date = selectedDateProv.selectedDate;
        final schedules = scheduleProv.itemsForDate(date);

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 상단 날짜 + 좌우 이동 + 검색
            Padding(
              padding:
                  const EdgeInsets.fromLTRB(16, 16, 16, 4),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () {
                      selectedDateProv
                          .setDate(date.subtract(const Duration(days: 1)));
                    },
                    icon: const Icon(Icons.chevron_left),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.center,
                      children: [
                        Text(
                          '${date.year}년 ${date.month}월 ${date.day}일',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          _weekdayText(date),
                          style: const TextStyle(fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () {
                      selectedDateProv
                          .setDate(date.add(const Duration(days: 1)));
                    },
                    icon: const Icon(Icons.chevron_right),
                  ),
                  IconButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const SearchSchedulePage(),
                        ),
                      );
                    },
                    icon: const Icon(Icons.search),
                  ),
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                '각 색깔 조각은 일정 시간만큼의 비율로 표시되고,\n조각 안에 일정 제목이 들어갑니다.',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: Center(
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final size = math.min(
                          constraints.maxWidth,
                          constraints.maxHeight,
                        ) *
                        0.9;
                    if (size <= 0) {
                      return const SizedBox.shrink();
                    }

                    final items = schedules.map((s) {
                      return _CircleSegmentItem(
                        schedule: s,
                        color: _colorFromHex(s.colorHex),
                      );
                    }).toList();

                    return GestureDetector(
                      onTapDown: (details) {
                        _handleTapOnCircle(
                          context: context,
                          localPos: details.localPosition,
                          size: size,
                          schedules: schedules,
                        );
                      },
                      child: SizedBox(
                        width: size,
                        height: size,
                        child: CustomPaint(
                          painter: _CirclePlannerPainter(items: items),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  String _weekdayText(DateTime date) {
    const names = ['월', '화', '수', '목', '금', '토', '일'];
    return names[date.weekday - 1];
  }

  Color _colorFromHex(String hex) {
    final buffer = StringBuffer();
    if (hex.length == 7 && hex.startsWith('#')) {
      buffer.write('ff');
      buffer.write(hex.replaceFirst('#', ''));
    } else if (hex.length == 9 && hex.startsWith('#')) {
      buffer.write(hex.replaceFirst('#', ''));
    } else {
      buffer.write('ff2196f3');
    }
    return Color(int.parse(buffer.toString(), radix: 16));
  }

  void _handleTapOnCircle({
    required BuildContext context,
    required Offset localPos,
    required double size,
    required List<ScheduleItem> schedules,
  }) {
    if (schedules.isEmpty) return;

    final center = Offset(size / 2, size / 2);
    final dx = localPos.dx - center.dx;
    final dy = localPos.dy - center.dy;
    final distance = math.sqrt(dx * dx + dy * dy);
    final outerRadius = size / 2;

    if (distance < 16 || distance > outerRadius) {
      return;
    }

    final angle = math.atan2(dy, dx);
    var angleFromTop = angle + math.pi / 2;
    if (angleFromTop < 0) {
      angleFromTop += 2 * math.pi;
    }
    final fraction = angleFromTop / (2 * math.pi);
    final minute = (fraction * 1440).round();

    ScheduleItem? tapped;
    for (final s in schedules) {
      final startMin = s.start.totalMinutes;
      final endMin = s.end.totalMinutes;
      if (startMin == endMin) continue;

      if (minute >= startMin && minute <= endMin) {
        tapped = s;
        break;
      }
    }

    if (tapped == null) return;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => ScheduleEditSheet(existing: tapped),
    );
  }
}

class _CircleSegmentItem {
  final ScheduleItem schedule;
  final Color color;

  _CircleSegmentItem({
    required this.schedule,
    required this.color,
  });
}

class _CirclePlannerPainter extends CustomPainter {
  final List<_CircleSegmentItem> items;

  _CirclePlannerPainter({
    required this.items,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = math.min(size.width, size.height) / 2 - 16;

    final circlePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..color = const Color(0xFF1A3E8A);

    canvas.drawCircle(center, radius, circlePaint);

    final centerDotPaint = Paint()
      ..color = const Color(0xFF1A3E8A)
      ..style = PaintingStyle.fill;
    canvas.drawCircle(center, 8, centerDotPaint);

    const hourTextStyle = TextStyle(
      fontSize: 11,
      color: Color(0xFF1A3E8A),
      fontWeight: FontWeight.w600,
    );

    for (int h = 0; h < 24; h++) {
      final angle = -math.pi / 2 + 2 * math.pi * (h / 24.0);
      final offsetRadius = radius + 14;

      final dx = center.dx + offsetRadius * math.cos(angle);
      final dy = center.dy + offsetRadius * math.sin(angle);
      final text = h.toString();

      final tp = TextPainter(
        text: TextSpan(text: text, style: hourTextStyle),
        textDirection: TextDirection.ltr,
      )..layout();

      final textOffset = Offset(
        dx - tp.width / 2,
        dy - tp.height / 2,
      );

      tp.paint(canvas, textOffset);
    }

    if (items.isEmpty) return;

    for (final item in items) {
      final s = item.schedule;
      final startMin = s.start.totalMinutes;
      final endMin = s.end.totalMinutes;
      if (endMin <= startMin) continue;

      final startAngle =
          -math.pi / 2 + 2 * math.pi * (startMin / 1440.0);
      final sweepAngle =
          2 * math.pi * ((endMin - startMin) / 1440.0);

      final baseColor = item.color;
      final fillPaint = Paint()
        ..style = PaintingStyle.fill
        ..color = baseColor.withOpacity(0.35);

      final strokePaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = baseColor.withOpacity(0.9);

      final rect = Rect.fromCircle(center: center, radius: radius - 8);

      final path = Path()
        ..moveTo(center.dx, center.dy)
        ..arcTo(rect, startAngle, sweepAngle, false)
        ..close();

      canvas.drawPath(path, fillPaint);
      canvas.drawPath(path, strokePaint);

      final midAngle = startAngle + sweepAngle / 2;
      final titleRadius = (radius - 30) * 0.6;

      final tx = center.dx + titleRadius * math.cos(midAngle);
      final ty = center.dy + titleRadius * math.sin(midAngle);

      final title = s.title;

      final titlePainter = TextPainter(
        text: TextSpan(
          text: title,
          style: const TextStyle(
            fontSize: 11,
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
        maxLines: 2,
        ellipsis: '…',
        textAlign: TextAlign.center,
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: radius * 0.7);

      final titleOffset = Offset(
        tx - titlePainter.width / 2,
        ty - titlePainter.height / 2,
      );

      titlePainter.paint(canvas, titleOffset);
    }
  }

  @override
  bool shouldRepaint(covariant _CirclePlannerPainter oldDelegate) {
    return !listEquals(oldDelegate.items, items);
  }
}
