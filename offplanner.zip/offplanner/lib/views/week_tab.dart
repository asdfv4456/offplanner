import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:offplanner/providers/selected_date_provider.dart';
import 'package:offplanner/providers/schedule_provider.dart';
import 'package:offplanner/models/schedule_item.dart';
import 'package:offplanner/models/custom_time.dart';

import 'package:offplanner/widgets/schedule_edit_sheet.dart';

class WeekTab extends StatefulWidget {
  const WeekTab({super.key});

  @override
  State<WeekTab> createState() => _WeekTabState();
}

class _WeekTabState extends State<WeekTab> {
  static const double _slotHeight = 56.0;

  @override
  Widget build(BuildContext context) {
    return Consumer2<SelectedDateProvider, ScheduleProvider>(
      builder: (context, selectedDateProv, scheduleProv, child) {
        final selected = selectedDateProv.selectedDate;
        final weekDates = _buildWeekDates(selected);
        final start = weekDates.first;
        final end = weekDates.last;

        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () {
                      final newDate =
                          selected.subtract(const Duration(days: 7));
                      selectedDateProv.setDate(newDate);
                    },
                    icon: const Icon(Icons.chevron_left),
                  ),
                  Expanded(
                    child: Column(
                      children: [
                        const Text(
                          '주간 시간표',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '${start.month}월 ${start.day}일 ~ ${end.month}월 ${end.day}일',
                          style: const TextStyle(fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  TextButton.icon(
                    onPressed: () => _copyWeekToNextWeek(context, weekDates),
                    icon: const Icon(Icons.copy, size: 18),
                    label: const Text(
                      '다음주 복사',
                      style: TextStyle(fontSize: 12),
                    ),
                  ),
                  IconButton(
                    onPressed: () {
                      final newDate = selected.add(const Duration(days: 7));
                      selectedDateProv.setDate(newDate);
                    },
                    icon: const Icon(Icons.chevron_right),
                  ),
                ],
              ),
            ),
            Container(
              color: Colors.grey.shade800,
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(
                children: [
                  Container(
                    width: 56,
                    decoration: BoxDecoration(
                      border: Border(
                        right: BorderSide(
                          color: Colors.grey.shade700,
                          width: 1,
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Row(
                      children: List.generate(weekDates.length, (index) {
                        final d = weekDates[index];
                        return Expanded(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                '${_weekdayKorean(d.weekday)}요일',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                '${d.month}/${d.day}',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 11,
                                ),
                              ),
                            ],
                          ),
                        );
                      }),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                child: SizedBox(
                  height: _slotHeight * 24,
                  child: Row(
                    children: [
                      SizedBox(
                        width: 56,
                        child: Stack(
                          children: [
                            Column(
                              children: List.generate(24, (i) {
                                return SizedBox(
                                  height: _slotHeight,
                                  child: Align(
                                    alignment: Alignment.topCenter,
                                    child: Container(
                                      height: 0.8,
                                      color: Colors.grey.shade300,
                                    ),
                                  ),
                                );
                              }),
                            ),
                            Column(
                              children: List.generate(24, (hour) {
                                final label =
                                    '${hour.toString().padLeft(2, '0')}:00';
                                return SizedBox(
                                  height: _slotHeight,
                                  child: Align(
                                    alignment: Alignment.center,
                                    child: Text(
                                      label,
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: Colors.grey.shade700,
                                      ),
                                    ),
                                  ),
                                );
                              }),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Row(
                          children: List.generate(weekDates.length, (index) {
                            final day = weekDates[index];
                            final daySchedules =
                                scheduleProv.itemsForDate(day);

                            return Expanded(
                              child: Container(
                                decoration: BoxDecoration(
                                  border: Border(
                                    left: BorderSide(
                                      color: Colors.grey.shade300,
                                      width: index == 0 ? 1 : 0.8,
                                    ),
                                    right: BorderSide(
                                      color: Colors.grey.shade300,
                                      width: index == weekDates.length - 1
                                          ? 1
                                          : 0.8,
                                    ),
                                  ),
                                ),
                                child: Stack(
                                  children: [
                                    Column(
                                      children: List.generate(24, (i) {
                                        return SizedBox(
                                          height: _slotHeight,
                                          child: Align(
                                            alignment: Alignment.topCenter,
                                            child: Container(
                                              height: 0.5,
                                              color: Colors.grey.shade300,
                                            ),
                                          ),
                                        );
                                      }),
                                    ),
                                    ...daySchedules.map(
                                      (s) =>
                                          _buildPositionedEvent(context, s),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          }),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildPositionedEvent(BuildContext context, ScheduleItem item) {
    final startMin = item.start.totalMinutes;
    final endMin = item.end.totalMinutes;

    final double minuteHeight = _slotHeight / 60.0;
    double top = startMin * minuteHeight;
    double height = (endMin - startMin) * minuteHeight;

    const double minHeight = 24.0;
    if (height < minHeight) height = minHeight;

    return Positioned(
      top: top + 2,
      left: 2,
      right: 2,
      height: height - 4,
      child: GestureDetector(
        onTap: () {
          showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            showDragHandle: true,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
            ),
            builder: (ctx) => ScheduleEditSheet(existing: item),
          );
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
          decoration: BoxDecoration(
            color: _colorFromHex(item.colorHex).withOpacity(0.9),
            borderRadius: BorderRadius.circular(4),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                item.title,
                style: const TextStyle(
                  fontSize: 10,
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
                overflow: TextOverflow.ellipsis,
              ),
              Text(
                _formatTimeRange(item),
                style: const TextStyle(
                  fontSize: 9,
                  color: Colors.white70,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<DateTime> _buildWeekDates(DateTime base) {
    final int weekday = base.weekday;
    final monday = base.subtract(Duration(days: weekday - 1));
    return List.generate(7, (i) {
      final d = monday.add(Duration(days: i));
      return DateTime(d.year, d.month, d.day);
    });
  }

  String _weekdayKorean(int weekday) {
    const names = ['월', '화', '수', '목', '금', '토', '일'];
    return names[weekday - 1];
  }

  String _formatTimeRange(ScheduleItem item) {
    return '${item.start.format()} ~ ${item.end.format()}';
  }

  Color _colorFromHex(String hex) {
    final buffer = StringBuffer();
    if (hex.length == 7 && hex.startsWith('#')) {
      buffer.write('ff');
      buffer.write(hex.replaceFirst('#', ''));
    } else if (hex.length == 9 && hex.startsWith('#')) {
      buffer.write(hex.replaceFirst('#', ''));
    } else {
      buffer.write('ff2196f3');
    }
    return Color(int.parse(buffer.toString(), radix: 16));
  }

  void _copyWeekToNextWeek(BuildContext context, List<DateTime> weekDates) {
    final scheduleProv = context.read<ScheduleProvider>();

    final List<ScheduleItem> source = [];
    for (final day in weekDates) {
      source.addAll(scheduleProv.itemsForDate(day));
    }

    if (source.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('복사할 일정이 없습니다.'),
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }

    final List<String> createdIds = [];
    int createdCount = 0;

    try {
      for (final item in source) {
        final newDate = item.date.add(const Duration(days: 7));
        final newId = DateTime.now().microsecondsSinceEpoch.toString();

        final newItem = ScheduleItem(
          id: newId,
          title: item.title,
          memo: item.memo,
          date: newDate,
          start: item.start,
          end: item.end,
          colorHex: item.colorHex,
          alarmEnabled: item.alarmEnabled,
          soundEnabled: item.soundEnabled,
          vibrationEnabled: item.vibrationEnabled,
          repeatType: item.repeatType,
          repeatInterval: item.repeatInterval,
        );

        scheduleProv.addSchedule(newItem);
        createdIds.add(newId);
        createdCount++;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('다음 주에 $createdCount개의 일정이 복사되었습니다.'),
          duration: const Duration(seconds: 2),
        ),
      );
    } catch (e) {
      for (final id in createdIds) {
        scheduleProv.deleteSchedule(id);
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString().replaceFirst('Exception: ', '')),
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }
}
