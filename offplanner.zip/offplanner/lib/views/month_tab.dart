// lib/views/month_tab.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:offplanner/providers/selected_date_provider.dart';
import 'package:offplanner/providers/schedule_provider.dart';
import 'package:offplanner/providers/dday_provider.dart';

import 'package:offplanner/models/dday_item.dart';
import 'package:offplanner/models/schedule_item.dart';

import 'package:offplanner/widgets/schedule_edit_sheet.dart';

class MonthTab extends StatefulWidget {
  const MonthTab({super.key});

  @override
  State<MonthTab> createState() => _MonthTabState();
}

class _MonthTabState extends State<MonthTab> {
  late DateTime _visibleMonth;

  @override
  void initState() {
    super.initState();
    final today = DateTime.now();
    _visibleMonth = DateTime(today.year, today.month, 1);
  }

  @override
  Widget build(BuildContext context) {
    return Consumer3<SelectedDateProvider, ScheduleProvider, DDayProvider>(
      builder: (context, selectedDateProv, scheduleProv, ddayProv, child) {
        final selectedDate = selectedDateProv.selectedDate;
        final ddayList = ddayProv.allItems;

        final firstDayOfMonth =
            DateTime(_visibleMonth.year, _visibleMonth.month, 1);


        final int weekdayOfFirst = firstDayOfMonth.weekday; 
        final int daysToSubtract = weekdayOfFirst - DateTime.monday;
        final gridStart = firstDayOfMonth.subtract(
          Duration(days: daysToSubtract < 0 ? 6 : daysToSubtract),
        );

        const totalCells = 42; 

        return Column(
          children: [
       
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    onPressed: () {
                      setState(() {
                        _visibleMonth = DateTime(
                          _visibleMonth.year,
                          _visibleMonth.month - 1,
                          1,
                        );
                      });
                    },
                    icon: const Icon(Icons.chevron_left),
                  ),
                  Text(
                    '${_visibleMonth.year}년 ${_visibleMonth.month}월',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  IconButton(
                    onPressed: () {
                      setState(() {
                        _visibleMonth = DateTime(
                          _visibleMonth.year,
                          _visibleMonth.month + 1,
                          1,
                        );
                      });
                    },
                    icon: const Icon(Icons.chevron_right),
                  ),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
              child: Row(
                children: const [
                  _WeekdayLabel('월'),
                  _WeekdayLabel('화'),
                  _WeekdayLabel('수'),
                  _WeekdayLabel('목'),
                  _WeekdayLabel('금'),
                  _WeekdayLabel('토'),
                  _WeekdayLabel('일'),
                ],
              ),
            ),
            const Divider(height: 1),

        
            Expanded(
              child: GridView.builder(
                padding:
                    const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 7,
                  childAspectRatio: 0.9,
                ),
                itemCount: totalCells,
                itemBuilder: (context, index) {
                  final day = gridStart.add(Duration(days: index));

                  final isCurrentMonth = day.month == _visibleMonth.month &&
                      day.year == _visibleMonth.year;
                  final isSelected = day.year == selectedDate.year &&
                      day.month == selectedDate.month &&
                      day.day == selectedDate.day;

                  final dailySchedules = scheduleProv.itemsForDate(day);
                  final hasSchedule = dailySchedules.isNotEmpty;

                  final ddayText = _buildDDayLabelForDate(ddayList, day);
                  final holidayName = _koreanHolidayName(day);

                  return GestureDetector(
                    onTap: () => _onTapDay(context, day),
                    onLongPress: () => _openCreateSheet(context, day),
                    child: Container(
                      margin: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? Theme.of(context)
                                .colorScheme
                                .primary
                                .withOpacity(0.08)
                            : null,
                        borderRadius: BorderRadius.circular(8),
                        border: isSelected
                            ? Border.all(
                                color:
                                    Theme.of(context).colorScheme.primary,
                                width: 1.4,
                              )
                            : null,
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 4,
                          vertical: 4,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            _buildDayHeader(
                              context: context,
                              day: day,
                              isCurrentMonth: isCurrentMonth,
                              isSelected: isSelected,
                              holidayName: holidayName,
                              ddayText: ddayText,
                            ),
                            const SizedBox(height: 4),
                            if (hasSchedule)
                              Expanded(
                                child: Align(
                                  alignment: Alignment.topLeft,
                                  child: _buildScheduleDots(dailySchedules),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildDayHeader({
    required BuildContext context,
    required DateTime day,
    required bool isCurrentMonth,
    required bool isSelected,
    required String? holidayName,
    required String? ddayText,
  }) {
    final isToday = _isToday(day);

    Color? dayColor;
    if (holidayName != null || day.weekday == DateTime.sunday) {
      dayColor = Colors.redAccent;
    } else if (day.weekday == DateTime.saturday) {
      dayColor = Colors.blueAccent;
    }

    if (!isCurrentMonth) {
      dayColor = (dayColor ?? Colors.black87).withOpacity(0.35);
    }

    final textStyle = TextStyle(
      fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
      fontSize: 12,
      color: dayColor,
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            if (isToday)
              Container(
                width: 18,
                height: 18,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Theme.of(context)
                      .colorScheme
                      .primary
                      .withOpacity(0.15),
                  shape: BoxShape.circle,
                ),
                child: Text(
                  '${day.day}',
                  style: textStyle.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              )
            else
              Text(
                '${day.day}',
                style: textStyle,
              ),
          ],
        ),
        const SizedBox(height: 2),
        if (holidayName != null)
          Text(
            holidayName,
            style: const TextStyle(
              fontSize: 9,
              color: Colors.redAccent,
              fontWeight: FontWeight.w600,
            ),
          ),
        if (holidayName != null) const SizedBox(height: 1),
        if (ddayText != null)
          Text(
            ddayText,
            style: const TextStyle(
              fontSize: 9,
              color: Colors.redAccent,
              fontWeight: FontWeight.w600,
            ),
          ),
      ],
    );
  }

  Widget _buildScheduleDots(List<ScheduleItem> items) {
    final limited = items.take(3).toList();
    if (limited.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: limited.map((e) {
        final color = _colorFromHex(e.colorHex);
        return Padding(
          padding: const EdgeInsets.only(bottom: 1.5),
          child: Row(
            children: [
              Container(
                width: 6,
                height: 6,
                decoration: BoxDecoration(
                  color: color,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 3),
              Expanded(
                child: Text(
                  e.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 9,
                  ),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  void _onTapDay(BuildContext context, DateTime day) {
    final selectedDateProv = context.read<SelectedDateProvider>();
    selectedDateProv.setDate(day);

    final scheduleProv = context.read<ScheduleProvider>();
    final items = scheduleProv.itemsForDate(day);
    if (items.isEmpty) return;

    _openScheduleListSheet(context, day, items);
  }

  void _openCreateSheet(BuildContext context, DateTime day) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) {
        return ScheduleEditSheet(
          initialDate: day,
          createDDayOnSave: false,
        );
      },
    );
  }

  void _openScheduleListSheet(
    BuildContext context,
    DateTime day,
    List<ScheduleItem> items,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) {
        return SafeArea(
          top: false,
          child: Padding(
            padding: EdgeInsets.only(
              left: 16,
              right: 16,
              top: 12,
              bottom: MediaQuery.of(ctx).viewInsets.bottom + 12,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  '${day.year}년 ${day.month}월 ${day.day}일 일정',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                if (items.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 16),
                    child: Text(
                      '이 날짜에는 일정이 없습니다.',
                      style: TextStyle(fontSize: 13),
                    ),
                  )
                else
                  Flexible(
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: items.length,
                      itemBuilder: (ctx2, index) {
                        final item = items[index];
                        return Card(
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          child: ListTile(
                            dense: true,
                            leading: Container(
                              width: 8,
                              height: 32,
                              decoration: BoxDecoration(
                                color: _colorFromHex(item.colorHex),
                                borderRadius: BorderRadius.circular(4),
                              ),
                            ),
                            title: Text(
                              item.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            subtitle: Text(
                              '${item.start.format()} ~ ${item.end.format()}',
                              style: const TextStyle(fontSize: 12),
                            ),
                            onTap: () {
                      
                              Navigator.of(ctx).pop();
                              _openEditSheet(context, item);
                            },
                          ),
                        );
                      },
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }


  void _openEditSheet(BuildContext context, ScheduleItem item) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      useRootNavigator: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) {
        return ScheduleEditSheet(
          existing: item,
          createDDayOnSave: false,
        );
      },
    );
  }


  String? _koreanHolidayName(DateTime date) {
    final m = date.month;
    final d = date.day;

    if (m == 1 && d == 1) return '신정';
    if (m == 3 && d == 1) return '삼일절';
    if (m == 5 && d == 5) return '어린이날';
    if (m == 6 && d == 6) return '현충일';
    if (m == 8 && d == 15) return '광복절';
    if (m == 10 && d == 3) return '개천절';
    if (m == 10 && d == 9) return '한글날';
    if (m == 12 && d == 25) return '성탄절';

    return null;
  }


  String? _buildDDayLabelForDate(List<DDayItem> ddayList, DateTime day) {
    for (final d in ddayList) {
      final t = DateTime(
        d.targetDate.year,
        d.targetDate.month,
        d.targetDate.day,
      );
      if (t.year == day.year &&
          t.month == day.month &&
          t.day == day.day &&
          d.isActive) {
        return _buildDDayText(t);
      }
    }
    return null;
  }

  String _buildDDayText(DateTime target) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final t = DateTime(target.year, target.month, target.day);

    final diff = t.difference(today).inDays;

    if (diff == 0) return 'D-Day';
    if (diff > 0) return 'D-${diff.abs()}';
    return 'D+${diff.abs()}';
  }

  bool _isToday(DateTime date) {
    final now = DateTime.now();
    return now.year == date.year &&
        now.month == date.month &&
        now.day == date.day;
  }

  Color _colorFromHex(String hex) {
    final buffer = StringBuffer();
    if (hex.length == 6 || hex.length == 7) buffer.write('ff');
    buffer.write(hex.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}

class _WeekdayLabel extends StatelessWidget {
  final String text;
  const _WeekdayLabel(this.text);

  @override
  Widget build(BuildContext context) {
    Color? color;
    if (text == '토') {
      color = Colors.blueAccent;
    } else if (text == '일') {
      color = Colors.redAccent;
    }

    return Expanded(
      child: Center(
        child: Text(
          text,
          style: TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 12,
            color: color,
          ),
        ),
      ),
    );
  }
}
