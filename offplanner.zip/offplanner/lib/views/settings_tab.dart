// lib/views/settings_tab.dart
import 'dart:io';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';

import 'package:offplanner/views/dday_manage_page.dart';
import 'package:offplanner/providers/app_settings_provider.dart';
import 'package:offplanner/providers/schedule_provider.dart';
import 'package:offplanner/providers/dday_provider.dart';
import 'package:offplanner/providers/daily_task_provider.dart';
import 'package:offplanner/services/backup_service.dart';
import 'package:offplanner/services/notification_service.dart';

class SettingsTab extends StatelessWidget {
  const SettingsTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppSettingsProvider>(
      builder: (context, appSettingsProv, _) {
        final s = appSettingsProv.settings;

        final presetColors = [
          '#4ecdc4',
          '#ff9f1c',
          '#e63946',
          '#4361ee',
          '#6c757d',
          '#FFB3BA',
          '#FFDFBA',
          '#FFFFBA',
          '#BAFFC9',
          '#BAE1FF',
          '#E3C4FF',
          '#F7C6C7',
          '#FFC9DE',
          '#FFF5C3',
          '#D7FFD9',
          '#D6E8FF',
          '#F0D9FF',
        ];

        return ListView(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          children: [
            const SizedBox(height: 12),

            const Text('알림',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),

            SwitchListTile(
              title: const Text('전체 알림'),
              subtitle: const Text('앱에서 보내는 모든 일정 알림을 켭니다'),
              value: s.notificationsEnabled,
              onChanged: (v) async {
                appSettingsProv.setNotificationsEnabled(v);

                final scheduleProv = context.read<ScheduleProvider>();
                final items = scheduleProv.allItems;

                if (!v) {
                  for (final item in items) {
                    await NotificationService().cancelForScheduleItem(item);
                  }
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('모든 일정 알림이 꺼졌습니다.')),
                    );
                  }
                } else {
                  for (final item in items) {
                    await NotificationService().scheduleForScheduleItem(item);
                  }
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                          content: Text('모든 일정 알림이 다시 예약되었습니다.')),
                    );
                  }
                }
              },
            ),

            SwitchListTile(
              title: const Text('진동 사용'),
              subtitle: const Text('알림이 울릴 때 기기 진동을 함께 사용합니다'),
              value: s.vibrationEnabled,
              onChanged: s.notificationsEnabled
                  ? (v) => appSettingsProv.setVibrationEnabled(v)
                  : null,
            ),

            if (s.notificationsEnabled && s.vibrationEnabled)
              ListTile(
                title: const Text('진동 세기'),
                subtitle: Text(_vibrationModeLabel(s.vibrationMode)),
                trailing: const Icon(Icons.chevron_right),
                onTap: () =>
                    _showVibrationModePicker(context, appSettingsProv),
              ),

            ListTile(
              title: const Text('알림 소리'),
              subtitle: Text(_soundLabel(s.notificationSound)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _showSoundPicker(context, appSettingsProv),
            ),

            ListTile(
              leading: const Icon(Icons.notifications_active),
              title: const Text('알림 테스트'),
              subtitle: const Text('알림이 정상 동작하는지 확인합니다'),
              onTap: () async {
                await NotificationService().showTestNotification(
                  s.notificationSound,
                  s.vibrationEnabled,
                );

                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('테스트 알림을 보냈습니다.')),
                  );
                }
              },
            ),

            const SizedBox(height: 24),

      
            const Text('데일리 기능',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),

            SwitchListTile(
              title: const Text('데일리 탭 사용'),
              subtitle:
                  const Text('끄면 데일리 탭이 숨고, 데일리 기능을 사용할 수 없습니다.'),
              value: s.dailyEnabled,
              onChanged: (v) {
                appSettingsProv.setDailyEnabled(v);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content:
                        Text(v ? '데일리 기능이 켜졌습니다.' : '데일리 기능이 꺼졌습니다.'),
                  ),
                );
              },
            ),

            const SizedBox(height: 24),

         
            const Text('종료 메시지',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),

            _ExitBucketSection(
                title: '0% (아무것도 완료 못함)',
                bucketKey: 'zero',
                provider: appSettingsProv),
            _ExitBucketSection(
                title: '1~49% (조금만 한 날)',
                bucketKey: 'low',
                provider: appSettingsProv),
            _ExitBucketSection(
                title: '50~79% (절반 이상)',
                bucketKey: 'mid',
                provider: appSettingsProv),
            _ExitBucketSection(
                title: '80~99% (거의 다 한 날)',
                bucketKey: 'high',
                provider: appSettingsProv),
            _ExitBucketSection(
                title: '100% (완벽한 날)',
                bucketKey: 'perfect',
                provider: appSettingsProv),
            _ExitBucketSection(
                title: '데일리 탭 OFF일 때',
                bucketKey: 'noDaily',
                provider: appSettingsProv),

            const SizedBox(height: 24),


            const Text('테마',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),

            Wrap(
              spacing: 8,
              children: [
                _ThemeChip(
                    label: '기본',
                    id: 'default',
                    currentId: s.theme,
                    onSelected: appSettingsProv.setTheme),
                _ThemeChip(
                    label: '라이트',
                    id: 'light',
                    currentId: s.theme,
                    onSelected: appSettingsProv.setTheme),
                _ThemeChip(
                    label: '다크',
                    id: 'dark',
                    currentId: s.theme,
                    onSelected: appSettingsProv.setTheme),
                _ThemeChip(
                    label: '민트',
                    id: 'mint',
                    currentId: s.theme,
                    onSelected: appSettingsProv.setTheme),
                _ThemeChip(
                    label: '퍼플',
                    id: 'purple',
                    currentId: s.theme,
                    onSelected: appSettingsProv.setTheme),
              ],
            ),

            const SizedBox(height: 24),

            const Text('시작 탭',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),

            ListTile(
              title: const Text('앱을 열었을 때 처음 보여줄 탭'),
              subtitle: Text(
                _startTabLabel(s.startTabId, s.dailyEnabled),
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _showStartTabPicker(context, appSettingsProv),
            ),

            const SizedBox(height: 24),



            const Text('기본 일정 색',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),

            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final hex in presetColors)
                  _ColorDot(
                    hex: hex,
                    selected: s.defaultScheduleColorHex == hex,
                    onTap: () => appSettingsProv.setDefaultScheduleColor(hex),
                  ),
                GestureDetector(
                  onTap: () {
                    _openColorPicker(
                      context,
                      s.defaultScheduleColorHex,
                      (newHex) =>
                          appSettingsProv.setDefaultScheduleColor(newHex),
                    );
                  },
                  child: Container(
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Theme.of(context).colorScheme.surface,
                      border: Border.all(
                          color: Theme.of(context).colorScheme.onSurface),
                    ),
                    child: const Icon(Icons.add, size: 16),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),


            const Text('배경 이미지',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),

            _BackgroundSettingTile(
              label: '표 플래너',
              tabKey: 'table',
              provider: appSettingsProv,
            ),
            _BackgroundSettingTile(
              label: '원형 플래너',
              tabKey: 'circle',
              provider: appSettingsProv,
            ),
            _BackgroundSettingTile(
              label: '주간 플래너',
              tabKey: 'week',
              provider: appSettingsProv,
            ),
            _BackgroundSettingTile(
              label: '월간 플래너',
              tabKey: 'month',
              provider: appSettingsProv,
            ),
            _BackgroundSettingTile(
              label: '데일리 플래너',
              tabKey: 'daily',
              provider: appSettingsProv,
            ),
            _BackgroundSettingTile(
              label: '설정 탭',
              tabKey: 'settings',
              provider: appSettingsProv,
            ),

            const SizedBox(height: 24),

 
            const Text('데이터',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),

            ListTile(
              leading: const Icon(Icons.download),
              title: const Text('데이터 백업'),
              subtitle: const Text('전체 데이터를 JSON 파일로 저장합니다.'),
              onTap: () async {
                final scheduleProv = context.read<ScheduleProvider>();
                final ddayProv = context.read<DDayProvider>();
                final dailyProv = context.read<DailyTaskProvider>();

                try {
                  final file = await BackupService().exportToFile(
                    appSettingsProv: appSettingsProv,
                    scheduleProv: scheduleProv,
                    ddayProv: ddayProv,
                    dailyProv: dailyProv,
                  );

                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('백업 완료: ${file.path}')),
                  );
                } catch (e) {
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('백업 중 오류: $e')),
                  );
                }
              },
            ),

            ListTile(
              leading: const Icon(Icons.upload),
              title: const Text('데이터 복원'),
              subtitle: const Text('JSON 파일로부터 데이터 복원'),
              onTap: () async {
                final result = await FilePicker.platform.pickFiles(
                  type: FileType.custom,
                  allowedExtensions: ['json'],
                );

                if (result == null || result.files.single.path == null) {
                  return;
                }

                final file = File(result.files.single.path!);

                final scheduleProv = context.read<ScheduleProvider>();
                final ddayProv = context.read<DDayProvider>();
                final dailyProv = context.read<DailyTaskProvider>();

                try {
                  await BackupService().restoreFromFile(
                    file,
                    appSettingsProv: appSettingsProv,
                    scheduleProv: scheduleProv,
                    ddayProv: ddayProv,
                    dailyProv: dailyProv,
                  );

                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('데이터 복원이 완료되었습니다!')),
                  );
                } catch (e) {
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('복원 중 오류: $e')),
                  );
                }
              },
            ),

            ListTile(
              leading: const Icon(Icons.delete_forever),
              title: const Text('앱 설정 초기화'),
              subtitle: const Text('일정/데일리/D-Day는 유지됩니다'),
              textColor: Colors.red,
              iconColor: Colors.red,
              onTap: () async {
                final ok = await showDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('정말 초기화할까요?'),
                        content: const Text('앱 설정만 초기화됩니다.'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.of(ctx).pop(false),
                            child: const Text('취소'),
                          ),
                          TextButton(
                            onPressed: () => Navigator.of(ctx).pop(true),
                            child:
                                const Text('초기화', style: TextStyle(color: Colors.red)),
                          ),
                        ],
                      ),
                    ) ??
                    false;

                if (ok) {
                  await appSettingsProv.resetSettings();
                  if (!context.mounted) return;

                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('앱 설정 초기화 완료')),
                  );
                }
              },
            ),

            const Divider(),
            ListTile(
              leading: const Icon(Icons.flag),
              title: const Text('D-Day 관리'),
              subtitle: const Text('D-Day를 추가/수정/삭제합니다'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const DDayManagePage()),
                );
              },
            ),

            const SizedBox(height: 16),

            const Divider(),
            const Text('앱 정보',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text('OffPlanner'),
              subtitle: Text('버전 0.1.0 (개발 중)'),
            ),
          ],
        );
      },
    );
  }



  String _soundLabel(String id) {
    switch (id) {
      case 'none':
        return '소리 없음';
      default:
        return '기본 알림음';
    }
  }

  String _vibrationModeLabel(String mode) {
    switch (mode) {
      case 'short':
        return '짧게 한 번';
      case 'strong':
        return '강하게 (여러 번)';
      case 'normal':
      default:
        return '보통';
    }
  }

  String _startTabLabel(String id, bool dailyEnabled) {
    switch (id) {
      case 'table':
        return '표 플래너';
      case 'circle':
        return '원형 플래너';
      case 'week':
        return '주간 플래너';
      case 'month':
        return '월간 플래너';
      case 'daily':
        return dailyEnabled ? '데일리 플래너' : '표 플래너';
      default:
        return '표 플래너';
    }
  }


  void _showSoundPicker(BuildContext context, AppSettingsProvider prov) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) {
        final current = prov.settings.notificationSound;

        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.only(bottom: 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                RadioListTile<String>(
                  title: const Text('기본 알림음'),
                  value: 'default',
                  groupValue: current,
                  onChanged: (v) {
                    prov.setNotificationSound(v ?? 'default');
                    Navigator.of(ctx).pop();
                  },
                ),
                RadioListTile<String>(
                  title: const Text('소리 없음'),
                  value: 'none',
                  groupValue: current,
                  onChanged: (v) {
                    prov.setNotificationSound(v ?? 'none');
                    Navigator.of(ctx).pop();
                  },
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showVibrationModePicker(
      BuildContext context, AppSettingsProvider prov) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) {
        final current = prov.settings.vibrationMode;

        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.only(bottom: 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                RadioListTile<String>(
                  title: const Text('짧게 한 번'),
                  value: 'short',
                  groupValue: current,
                  onChanged: (v) {
                    prov.setVibrationMode(v ?? 'short');
                    Navigator.of(ctx).pop();
                  },
                ),
                RadioListTile<String>(
                  title: const Text('보통'),
                  value: 'normal',
                  groupValue: current,
                  onChanged: (v) {
                    prov.setVibrationMode(v ?? 'normal');
                    Navigator.of(ctx).pop();
                  },
                ),
                RadioListTile<String>(
                  title: const Text('강하게 (여러 번)'),
                  value: 'strong',
                  groupValue: current,
                  onChanged: (v) {
                    prov.setVibrationMode(v ?? 'strong');
                    Navigator.of(ctx).pop();
                  },
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showStartTabPicker(
      BuildContext context, AppSettingsProvider prov) {
    final s = prov.settings;
    final current = s.startTabId;
    final dailyEnabled = s.dailyEnabled;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) {
        final options = <Map<String, String>>[
          {'id': 'table', 'label': '표 플래너'},
          {'id': 'circle', 'label': '원형 플래너'},
          {'id': 'week', 'label': '주간 플래너'},
          {'id': 'month', 'label': '월간 플래너'},
        ];

        if (dailyEnabled) {
          options.add({'id': 'daily', 'label': '데일리 플래너'});
        }

        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.only(bottom: 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (final opt in options)
                  RadioListTile<String>(
                    title: Text(opt['label']!),
                    value: opt['id']!,
                    groupValue: current,
                    onChanged: (v) {
                      if (v == null) return;
                      prov.setStartTabId(v);
                      Navigator.of(ctx).pop();
                    },
                  ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        );
      },
    );
  }
}


class _ExitBucketSection extends StatelessWidget {
  final String title;
  final String bucketKey;
  final AppSettingsProvider provider;

  const _ExitBucketSection({
    required this.title,
    required this.bucketKey,
    required this.provider,
  });

  @override
  Widget build(BuildContext context) {
    final messages = provider.getExitMessagesForBucket(bucketKey);

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ExpansionTile(
        title: Text(title, style: const TextStyle(fontSize: 14)),
        childrenPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        children: [
          if (messages.isEmpty)
            const ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text('등록된 메시지가 없습니다.',
                  style: TextStyle(fontSize: 13)),
              subtitle: Text('아래 버튼을 눌러 메시지를 추가하세요.',
                  style: TextStyle(fontSize: 12)),
            )
          else
            Column(
              children: [
                for (int i = 0; i < messages.length; i++)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title:
                        Text(messages[i], style: const TextStyle(fontSize: 13)),
                    onTap: () {
                      _showExitMessageEditor(
                        context,
                        initialText: messages[i],
                        onSave: (newText) => provider.updateExitMessage(
                            bucketKey, i, newText),
                      );
                    },
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit, size: 18),
                          onPressed: () {
                            _showExitMessageEditor(
                              context,
                              initialText: messages[i],
                              onSave: (newText) =>
                                  provider.updateExitMessage(
                                      bucketKey, i, newText),
                            );
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete, size: 18),
                          onPressed: () =>
                              _deleteExitMessage(context, bucketKey, i),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          Align(
            alignment: Alignment.centerLeft,
            child: OutlinedButton.icon(
              icon: const Icon(Icons.add, size: 18),
              label: const Text('메시지 추가',
                  style: TextStyle(fontSize: 13)),
              onPressed: () {
                _showExitMessageEditor(
                  context,
                  onSave: (newText) =>
                      provider.addExitMessage(bucketKey, newText),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _deleteExitMessage(
      BuildContext context, String bucketKey, int index) async {
    final ok = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('메시지 삭제'),
            content: const Text('이 종료 메시지를 삭제할까요?'),
            actions: [
              TextButton(
                  onPressed: () => Navigator.of(ctx).pop(false),
                  child: const Text('취소')),
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(true),
                child:
                    const Text('삭제', style: TextStyle(color: Colors.red)),
              ),
            ],
          ),
        ) ??
        false;

    if (ok) {
      provider.removeExitMessage(bucketKey, index);
    }
  }

  void _showExitMessageEditor(
    BuildContext context, {
    String? initialText,
    required ValueChanged<String> onSave,
  }) {
    final controller = TextEditingController(text: initialText ?? '');

    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(initialText == null ? '메시지 추가' : '메시지 수정'),
        content: TextField(
          controller: controller,
          maxLines: 3,
          decoration:
              const InputDecoration(hintText: '종료 메시지를 입력하세요'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('취소'),
          ),
          TextButton(
            onPressed: () {
              final text = controller.text.trim();
              if (text.isNotEmpty) {
                onSave(text);
                Navigator.of(ctx).pop();
              }
            },
            child: const Text('저장'),
          ),
        ],
      ),
    );
  }
}

class _ThemeChip extends StatelessWidget {
  final String label;
  final String id;
  final String currentId;
  final ValueChanged<String> onSelected;

  const _ThemeChip({
    required this.label,
    required this.id,
    required this.currentId,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    final selected = id == currentId;
    return ChoiceChip(
      label: Text(label),
      selected: selected,
      onSelected: (_) => onSelected(id),
    );
  }
}


class _ColorDot extends StatelessWidget {
  final String hex;
  final bool selected;
  final VoidCallback onTap;

  const _ColorDot({
    required this.hex,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = _colorFromHex(hex);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 28,
        height: 28,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(
            color: selected
                ? (isDark ? Colors.white : Colors.black)
                : Theme.of(context).colorScheme.onSurface,
            width: selected ? 2 : 1,
          ),
        ),
      ),
    );
  }
}

Color _colorFromHex(String hex) {
  final buffer = StringBuffer();
  if (hex.length == 7 && hex.startsWith('#')) {
    buffer.write('ff');
    buffer.write(hex.replaceFirst('#', ''));
  } else if (hex.length == 9 && hex.startsWith('#')) {
    buffer.write(hex.replaceFirst('#', ''));
  } else {
    buffer.write('ff4ecdc4');
  }
  return Color(int.parse(buffer.toString(), radix: 16));
}

void _openColorPicker(
  BuildContext context,
  String initialHex,
  ValueChanged<String> onColorSelected,
) {
  Color currentColor = _colorFromHex(initialHex);

  showDialog(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text("색 선택"),
      content: SingleChildScrollView(
        child: ColorPicker(
          pickerColor: currentColor,
          onColorChanged: (c) => currentColor = c,
          enableAlpha: false,
          labelTypes: const [],
          pickerAreaHeightPercent: 0.7,
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("취소")),
        TextButton(
          onPressed: () {
            final hex =
                '#${currentColor.value.toRadixString(16).substring(2)}';
            onColorSelected(hex);
            Navigator.pop(ctx);
          },
          child: const Text("선택"),
        ),
      ],
    ),
  );
}



class _BackgroundSettingTile extends StatelessWidget {
  final String label;
  final String tabKey;
  final AppSettingsProvider provider;

  const _BackgroundSettingTile({
    required this.label,
    required this.tabKey,
    required this.provider,
  });

  @override
  Widget build(BuildContext context) {
    final base64 = provider.backgroundImageForTab(tabKey);
    final hasImage = base64 != null && base64.isNotEmpty;
    final opacity = provider.backgroundOpacityForTab(tabKey);
    final blur = provider.backgroundBlurForTab(tabKey);

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ExpansionTile(
        title: Text(label),
        subtitle: Text(
          hasImage ? '배경 설정됨' : '배경 없음',
          style: const TextStyle(fontSize: 12),
        ),
        childrenPadding:
            const EdgeInsets.fromLTRB(16, 0, 16, 12),
        children: [
          Row(
            children: [
              ElevatedButton.icon(
                icon: const Icon(Icons.image),
                label: const Text('사진 선택'),
                onPressed: () => _pickImage(context),
              ),
              const SizedBox(width: 8),
              TextButton(
                onPressed: hasImage
                    ? () =>
                        provider.setBackgroundImageForTab(tabKey, null)
                    : null,
                child: const Text('초기화'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          const Text(
            '투명도 (배경 위 흰 레이어)',
            style: TextStyle(fontSize: 12),
          ),
          Slider(
            value: opacity,
            min: 0.0,
            max: 0.8,
            divisions: 8,
            label: opacity.toStringAsFixed(2),
            onChanged: (v) {
              provider.setBackgroundOpacityForTab(tabKey, v);
            },
          ),
          const SizedBox(height: 4),
          const Text(
            '블러 정도',
            style: TextStyle(fontSize: 12),
          ),
          Slider(
            value: blur,
            min: 0.0,
            max: 20.0,
            divisions: 20,
            label: blur.toStringAsFixed(0),
            onChanged: (v) {
              provider.setBackgroundBlurForTab(tabKey, v);
            },
          ),
        ],
      ),
    );
  }

  Future<void> _pickImage(BuildContext context) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.image,
      withData: true,
    );
    if (result == null || result.files.single.bytes == null) {
      return;
    }

    final bytes = result.files.single.bytes!;
    final base64Str = base64Encode(bytes);
    provider.setBackgroundImageForTab(tabKey, base64Str);

    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$label 배경이 변경되었습니다.')),
      );
    }
  }
}
