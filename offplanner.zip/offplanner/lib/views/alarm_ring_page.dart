// lib/views/alarm_ring_page.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:vibration/vibration.dart';

import 'package:offplanner/services/notification_service.dart';
import 'package:offplanner/providers/app_settings_provider.dart';

class AlarmRingPage extends StatefulWidget {
  final String title;
  final String body;

  const AlarmRingPage({
    super.key,
    required this.title,
    required this.body,
  });

  @override
  State<AlarmRingPage> createState() => _AlarmRingPageState();
}

class _AlarmRingPageState extends State<AlarmRingPage> {
  @override
  void initState() {
    super.initState();
    _startVibrationIfNeeded();
  }

  Future<void> _startVibrationIfNeeded() async {
    final settings =
        Provider.of<AppSettingsProvider>(context, listen: false).settings;

    if (!settings.vibrationEnabled) return;

    final hasVib = await Vibration.hasVibrator() ?? false;
    if (!hasVib) return;

    final mode = settings.vibrationMode;

    if (mode == 'short') {
      // 짧게 한 번
      Vibration.vibrate(duration: 300);
    } else if (mode == 'strong') {
      // 강하게: 여러 번 / 비교적 길게
      Vibration.vibrate(pattern: [
        0,
        600,
        200,
        600,
        200,
        600,
      ]);
    } else {
      // normal
      Vibration.vibrate(duration: 1200);
    }
  }

  void _stopVibration() {
    Vibration.cancel();
  }

  void _dismiss() {
    _stopVibration();
    Navigator.of(context).pop();
  }

  Future<void> _snooze() async {
    final settings =
        Provider.of<AppSettingsProvider>(context, listen: false).settings;

    await NotificationService().scheduleSnooze(
      title: widget.title,
      body: widget.body,
      soundId: settings.notificationSound,
      vibrationEnabled: settings.vibrationEnabled,
    );

    if (!mounted) return;

    _stopVibration();

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('5분 뒤에 알람이 한 번 더 울립니다.'),
        duration: Duration(seconds: 2),
      ),
    );
    Navigator.of(context).pop();
  }

  @override
  void dispose() {
    _stopVibration();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;

    return Scaffold(
      backgroundColor: cs.primaryContainer.withOpacity(0.9),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // 상단 알람 정보 + 안내
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 16),
                  Icon(
                    Icons.alarm,
                    size: 72,
                    color: cs.primary,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    '알람이 울리고 있어요',
                    style: theme.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    widget.title,
                    style: theme.textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    widget.body,
                    style: theme.textTheme.bodyMedium,
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),

                  // 🔥 다시 울리기 안내 박스
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: cs.surface.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '⏰ 5분 뒤에 다시 울리게 하고 싶다면?',
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '[5분 뒤 다시 울리기] 버튼을 누르면\n'
                          '알람이 자동으로 5분 뒤에 한 번 더 울려요.',
                          style: theme.textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              // 하단 버튼 영역
              Column(
                children: [
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: _snooze,
                      style: FilledButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                          vertical: 16,
                        ),
                        textStyle: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      child: const Text('5분 뒤 다시 울리기'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: _dismiss,
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                          vertical: 14,
                        ),
                        textStyle: theme.textTheme.titleMedium,
                      ),
                      child: const Text('확인하고 끄기'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
