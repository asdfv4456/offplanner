// lib/views/daily_tab.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:offplanner/providers/selected_date_provider.dart';
import 'package:offplanner/providers/daily_task_provider.dart';
import 'package:offplanner/views/search_schedule_page.dart';

class DailyTab extends StatelessWidget {
  const DailyTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer2<SelectedDateProvider, DailyTaskProvider>(
      builder: (context, selectedDateProv, dailyProv, child) {
        final date = selectedDateProv.selectedDate;
        final tasks = dailyProv.tasksForDate(date);
        final rate = dailyProv.completionRate(date);
        final percent = (rate * 100).round();

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
  
            Padding(
              padding:
                  const EdgeInsets.fromLTRB(16, 16, 16, 4),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () {
                      final newDate = date.subtract(
                        const Duration(days: 1),
                      );
                      selectedDateProv.setDate(newDate);
                    },
                    icon: const Icon(Icons.chevron_left),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${date.year}년 ${date.month}월 ${date.day}일',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          _weekdayKorean(date),
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () {
                      final newDate =
                          date.add(const Duration(days: 1));
                      selectedDateProv.setDate(newDate);
                    },
                    icon: const Icon(Icons.chevron_right),
                  ),
                  IconButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const SearchSchedulePage(),
                        ),
                      );
                    },
                    icon: const Icon(Icons.search),
                  ),
                ],
              ),
            ),


            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                '오늘 하고 싶은 일들을 체크리스트로 관리해 보세요.\n'
                '완료율은 앱 종료 시 긍정 멘트에도 사용됩니다.',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ),
            const SizedBox(height: 8),


            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text(
                        '오늘 완료율',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '$percent%',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.blueAccent,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      minHeight: 8,
                      value: tasks.isEmpty ? 0.0 : rate,
                      backgroundColor: Colors.grey.shade200,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 12),


            Expanded(
              child: Column(
                children: [
           
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: TextButton.icon(
                        onPressed: () =>
                            _showAddTaskDialog(context, date),
                        icon: const Icon(Icons.add),
                        label: const Text('할 일 추가'),
                      ),
                    ),
                  ),

                  Expanded(
                    child: tasks.isEmpty
                        ? const Center(
                            child: Text(
                              '아직 추가한 할 일이 없습니다.\n오른쪽 위 [할 일 추가] 버튼을 눌러보세요.',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey,
                              ),
                            ),
                          )
                        : ListView.separated(
                            padding: const EdgeInsets.fromLTRB(
                                16, 0, 16, 16),
                            itemCount: tasks.length,
                            separatorBuilder: (_, __) =>
                                const SizedBox(height: 4),
                            itemBuilder: (context, index) {
                              final task = tasks[index];
                              return Dismissible(
                                key: ValueKey(task.id),
                                direction: DismissDirection.endToStart,
                                background: Container(
                                  alignment: Alignment.centerRight,
                                  padding: const EdgeInsets.only(
                                      right: 16),
                                  color:
                                      Colors.red.withOpacity(0.85),
                                  child: const Icon(
                                    Icons.delete,
                                    color: Colors.white,
                                  ),
                                ),
                                onDismissed: (_) {
                                  dailyProv.removeTask(date, task.id);
                                },
                                child: Card(
                                  elevation: 0,
                                  shape: RoundedRectangleBorder(
                                    borderRadius:
                                        BorderRadius.circular(8),
                                  ),
                                  child: CheckboxListTile(
                                    shape: RoundedRectangleBorder(
                                      borderRadius:
                                          BorderRadius.circular(8),
                                    ),
                                    contentPadding:
                                        const EdgeInsets.symmetric(
                                      horizontal: 12,
                                      vertical: 0,
                                    ),
                                    title: Text(
                                      task.title,
                                      style: TextStyle(
                                        decoration: task.isDone
                                            ? TextDecoration
                                                .lineThrough
                                            : TextDecoration.none,
                                        color: task.isDone
                                            ? Colors.grey
                                            : null,
                                      ),
                                    ),
                                    value: task.isDone,
                                    onChanged: (_) {
                                      dailyProv.toggleTask(
                                          date, task.id);
                                    },
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  static String _weekdayKorean(DateTime date) {
    const names = ['월요일', '화요일', '수요일', '목요일', '금요일', '토요일', '일요일'];
    return names[date.weekday - 1];
  }

  void _showAddTaskDialog(BuildContext context, DateTime date) {
    final controller = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('할 일 추가'),
          content: TextField(
            controller: controller,
            decoration: const InputDecoration(
              labelText: '할 일 내용',
              hintText: '예) 과제 조금 하기, 10분 걷기',
            ),
            autofocus: true,
            onSubmitted: (_) =>
                _submit(ctx, date, controller.text),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('취소'),
            ),
            ElevatedButton(
              onPressed: () =>
                  _submit(ctx, date, controller.text),
              child: const Text('추가'),
            ),
          ],
        );
      },
    );
  }

  void _submit(
      BuildContext dialogContext, DateTime date, String text) {
    final title = text.trim();
    if (title.isEmpty) {
      Navigator.of(dialogContext).pop();
      return;
    }
    final dailyProv = dialogContext.read<DailyTaskProvider>();
    dailyProv.addTask(date, title);
    Navigator.of(dialogContext).pop();
  }
}
