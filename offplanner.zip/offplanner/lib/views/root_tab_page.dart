// lib/views/root_tab_page.dart
import 'dart:math';
import 'dart:convert';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'package:offplanner/providers/selected_date_provider.dart';
import 'package:offplanner/providers/daily_task_provider.dart';
import 'package:offplanner/providers/app_settings_provider.dart';

import 'package:offplanner/views/table_tab.dart';
import 'package:offplanner/views/circle_tab.dart';
import 'package:offplanner/views/week_tab.dart';
import 'package:offplanner/views/month_tab.dart';
import 'package:offplanner/views/daily_tab.dart';
import 'package:offplanner/views/settings_tab.dart';

import 'package:offplanner/widgets/dday_header.dart';
import 'package:offplanner/widgets/schedule_edit_sheet.dart';

class RootTabPage extends StatefulWidget {
  const RootTabPage({super.key});

  @override
  State<RootTabPage> createState() => _RootTabPageState();
}

class _RootTabPageState extends State<RootTabPage> {
  int _currentIndex = -1; 


  String _bucket(int percent) {
    if (percent >= 100) return 'perfect';
    if (percent >= 80) return 'high';
    if (percent >= 50) return 'mid';
    if (percent > 0) return 'low';
    return 'zero';
  }


  int _indexFromStartTab(String id, bool daily) {
    switch (id) {
      case 'table':
        return 0;
      case 'circle':
        return 1;
      case 'week':
        return 2;
      case 'month':
        return 3;
      case 'daily':
        return daily ? 4 : 0;
      default:
        return 0;
    }
  }


  String _tabKey(int index, bool daily) {
    if (index == 0) return 'table';
    if (index == 1) return 'circle';
    if (index == 2) return 'week';
    if (index == 3) return 'month';
    if (daily) {
      if (index == 4) return 'daily';
      if (index == 5) return 'settings';
    } else {
      if (index == 4) return 'settings';
    }
    return 'table';
  }

  @override
  Widget build(BuildContext context) {
    final settingsProv = context.watch<AppSettingsProvider>();

    if (!settingsProv.isLoaded) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final settings = settingsProv.settings;
    final dailyEnabled = settings.dailyEnabled;

    if (_currentIndex == -1) {
      _currentIndex = _indexFromStartTab(settings.startTabId, dailyEnabled);
    }


    final tabTitles = [
      '표 플래너',
      '원형 플래너',
      '주간 플래너',
      '월간 플래너',
      if (dailyEnabled) '데일리 플래너',
      '설정',
    ];

    final tabIcons = [
      Icons.table_chart_outlined,
      Icons.pie_chart_outline,
      Icons.view_week_outlined,
      Icons.calendar_month_outlined,
      if (dailyEnabled) Icons.checklist_outlined,
      Icons.settings_outlined,
    ];

    final tabBodies = [
      const TableTab(),
      const CircleTab(),
      const WeekTab(),
      const MonthTab(),
      if (dailyEnabled) const DailyTab(),
      const SettingsTab(),
    ];

    if (_currentIndex >= tabTitles.length) {
      _currentIndex = tabTitles.length - 1;
    }

    final isSettingsTab = _currentIndex == tabTitles.length - 1;

 
    final tabKey = _tabKey(_currentIndex, dailyEnabled);
    final bgImg = settingsProv.backgroundImageForTab(tabKey);
    final bgOpacity = settingsProv.backgroundOpacityForTab(tabKey);
    final bgBlur = settingsProv.backgroundBlurForTab(tabKey);

    return PopScope(
      canPop: false, 
      onPopInvoked: (didPop) async {
        if (didPop) return;

        final shouldExit = await _showExitDialog(context);
        if (shouldExit) SystemNavigator.pop();
      },
      child: Scaffold(
        appBar: AppBar(title: Text(tabTitles[_currentIndex])),
        body: _TabBackground(
          base64Image: bgImg,
          overlayOpacity: bgOpacity,
          blurSigma: bgBlur,
          child: Column(
            children: [
              const DDayHeader(),
              const Divider(height: 1),
              Expanded(child: tabBodies[_currentIndex]),
            ],
          ),
        ),
        floatingActionButton: isSettingsTab
            ? null
            : FloatingActionButton.extended(
                onPressed: () => _openAddBottomSheet(context),
                icon: const Icon(Icons.add),
                label: const Text('일정 추가'),
              ),
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          currentIndex: _currentIndex,
          onTap: (i) => setState(() => _currentIndex = i),
          items: List.generate(tabTitles.length, (i) {
            return BottomNavigationBarItem(
              icon: Icon(tabIcons[i]),
              label: tabTitles[i],
            );
          }),
        ),
      ),
    );
  }

  Future<bool> _showExitDialog(BuildContext context) async {
    final settingsProv = context.read<AppSettingsProvider>();
    final s = settingsProv.settings;

    String text;

    if (s.dailyEnabled) {
      final date = context.read<SelectedDateProvider>().selectedDate;
      final daily = context.read<DailyTaskProvider>();
      final percent = (daily.completionRate(date) * 100).round();

      final bucket = _bucket(percent);
      final msgs = settingsProv.getExitMessagesForBucket(bucket);
      final msg =
          msgs.isNotEmpty ? msgs[Random().nextInt(msgs.length)] : '오늘 잘해냈어요!';

      text = '오늘 달성률: $percent%\n\n$msg';
    } else {
      final msgs = settingsProv.getExitMessagesForBucket('noDaily');
      final msg =
          msgs.isNotEmpty ? msgs[Random().nextInt(msgs.length)] : '오늘도 수고했어요!';
      text = msg;
    }

    return await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text("오늘 하루 돌아보기"),
            content: Text(text),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text("계속 사용할래요"),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text("앱 종료할래요"),
              ),
            ],
          ),
        ) ??
        false;
  }


  void _openAddBottomSheet(BuildContext context) {
    final date = context.read<SelectedDateProvider>().selectedDate;
    final createDDay = _currentIndex == 3;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true, 
      showDragHandle: true,
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.92, 
      ),
      builder: (ctx) => ScheduleEditSheet(
        initialDate: date,
        createDDayOnSave: createDDay,
      ),
    );
  }
}

class _TabBackground extends StatelessWidget {
  final String? base64Image;
  final double overlayOpacity;
  final double blurSigma;
  final Widget child;

  const _TabBackground({
    required this.base64Image,
    required this.overlayOpacity,
    required this.blurSigma,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    if (base64Image == null || base64Image!.isEmpty) {
      return child;
    }

    List<int> bytes;
    try {
      bytes = base64Decode(base64Image!);
    } catch (_) {
      return child;
    }

    return Stack(
      children: [
        Positioned.fill(
          child: Image.memory(bytes as Uint8List, fit: BoxFit.cover),
        ),
        Positioned.fill(
          child: BackdropFilter(
            filter: ui.ImageFilter.blur(
              sigmaX: blurSigma,
              sigmaY: blurSigma,
            ),
            child: Container(
              color: Colors.white.withOpacity(
                overlayOpacity.clamp(0.0, 1.0),
              ),
            ),
          ),
        ),
        child,
      ],
    );
  }
}
