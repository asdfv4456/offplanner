// lib/models/dday_item.dart

class DDayItem {
  final String id;
  final String title;
  final DateTime targetDate;
  final String colorHex;
  final bool isActive;

  const DDayItem({
    required this.id,
    required this.title,
    required this.targetDate,
    required this.colorHex,
    this.isActive = true,
  });

  DDayItem copyWith({
    String? id,
    String? title,
    DateTime? targetDate,
    String? colorHex,
    bool? isActive,
  }) {
    return DDayItem(
      id: id ?? this.id,
      title: title ?? this.title,
      targetDate: targetDate ?? this.targetDate,
      colorHex: colorHex ?? this.colorHex,
      isActive: isActive ?? this.isActive,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'targetDate': targetDate.toIso8601String(),
      'colorHex': colorHex,
      'isActive': isActive,
    };
  }

  factory DDayItem.fromJson(Map<String, dynamic> json) {
    return DDayItem(
      id: json['id'] as String? ?? '',
      title: json['title'] as String? ?? '',
      targetDate: DateTime.tryParse(json['targetDate'] as String? ?? '') ??
          DateTime.now(),
      colorHex: json['colorHex'] as String? ?? '#ff2196f3',
      isActive: json['isActive'] as bool? ?? true,
    );
  }
}
