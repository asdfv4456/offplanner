// lib/models/repeat_types.dart
enum RepeatType {
  none,
  daily,
  weekly,
}

enum RepeatEndType {
  date,
  count,
  infinite,
}
