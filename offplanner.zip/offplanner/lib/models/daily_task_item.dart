// lib/models/daily_task_item.dart
class DailyTaskItem {
  final String id;
  final DateTime date; 
  final String text;
  final bool done;

  DailyTaskItem({
    required this.id,
    required this.date,
    required this.text,
    required this.done,
  });

  DailyTaskItem copyWith({
    String? id,
    DateTime? date,
    String? text,
    bool? done,
  }) {
    return DailyTaskItem(
      id: id ?? this.id,
      date: date ?? this.date,
      text: text ?? this.text,
      done: done ?? this.done,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'date': date.toIso8601String(),
      'text': text,
      'done': done,
    };
  }

  factory DailyTaskItem.fromJson(Map<String, dynamic> json) {
    return DailyTaskItem(
      id: json['id'] as String? ?? '',
      date: DateTime.tryParse(json['date'] as String? ?? '') ??
          DateTime.now(),
      text: json['text'] as String? ?? '',
      done: json['done'] as bool? ?? false,
    );
  }
}
