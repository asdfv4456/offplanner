// lib/models/schedule_item.dart
import 'package:offplanner/models/custom_time.dart';
import 'package:offplanner/models/repeat_types.dart';

class ScheduleItem {
  final String id;
  final String title;
  final String? memo;
  final DateTime date;


  final CustomTime start;
  final CustomTime end;

  final String colorHex;

  final bool alarmEnabled;
  final bool soundEnabled;
  final bool vibrationEnabled;

  final RepeatType repeatType;
  final int? repeatInterval;

  ScheduleItem({
    required this.id,
    required this.title,
    required this.memo,
    required this.date,
    required this.start,
    required this.end,
    required this.colorHex,
    required this.alarmEnabled,
    required this.soundEnabled,
    required this.vibrationEnabled,
    this.repeatType = RepeatType.none,
    this.repeatInterval,
  }) : assert(end.totalMinutes > start.totalMinutes);


  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'memo': memo,
      'date': date.toIso8601String(),
      'start': start.totalMinutes,
      'end': end.totalMinutes,
      'colorHex': colorHex,
      'alarmEnabled': alarmEnabled,
      'soundEnabled': soundEnabled,
      'vibrationEnabled': vibrationEnabled,
      'repeatType': repeatType.name,
      'repeatInterval': repeatInterval,
    };
  }

  factory ScheduleItem.fromJson(Map<String, dynamic> json) {
    return ScheduleItem(
      id: json['id'],
      title: json['title'],
      memo: json['memo'],
      date: DateTime.parse(json['date']),
      start: CustomTime(json['start']),
      end: CustomTime(json['end']),
      colorHex: json['colorHex'],
      alarmEnabled: json['alarmEnabled'] ?? false,
      soundEnabled: json['soundEnabled'] ?? true,
      vibrationEnabled: json['vibrationEnabled'] ?? true,
      repeatType: RepeatType.values.firstWhere(
        (e) => e.name == (json['repeatType'] ?? 'none'),
        orElse: () => RepeatType.none,
      ),
      repeatInterval: json['repeatInterval'],
    );
  }
}
