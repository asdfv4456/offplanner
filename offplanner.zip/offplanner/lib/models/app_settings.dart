// lib/models/app_settings.dart
import 'package:flutter/foundation.dart';

@immutable
class AppSettings {
  final bool notificationsEnabled;
  final bool vibrationEnabled;

  final String notificationSound;

  final String vibrationMode;

  final String theme;

  final String defaultScheduleColorHex;

  final bool dailyEnabled;

  final String startTabId;

  final List<String> exitMsgZero;
  final List<String> exitMsgLow;
  final List<String> exitMsgMid;
  final List<String> exitMsgHigh;
  final List<String> exitMsgPerfect;
  final List<String> exitMsgNoDaily;

  final Map<String, String?> backgroundImages;

  final Map<String, double> backgroundOpacity;

  final Map<String, double> backgroundBlur;

  const AppSettings({
    this.notificationsEnabled = true,
    this.vibrationEnabled = true,
    this.notificationSound = 'default',
    this.vibrationMode = 'normal',
    this.theme = 'default',
    this.defaultScheduleColorHex = '#4ecdc4',
    this.dailyEnabled = true,
    this.startTabId = 'table',

    this.exitMsgZero = const [
      '오늘은 쉬어가는 날이었어요. 그 자체로 충분히 의미 있어요.',
      '아무것도 못 한 날이 아니라, 쉬어야 했던 날일 뿐이에요.',
      '지금까지 버틴 나만으로도 충분히 잘하고 있어요.',
    ],
    this.exitMsgLow = const [
      '조금이라도 움직였다면, 이미 어제보다 나아진 거예요.',
      '시작했다는 것만으로도 큰 의미가 있어요.',
      '오늘의 작은 시도가 내일을 만들어줘요.',
    ],
    this.exitMsgMid = const [
      '절반 이상 해냈어요. 정말 훌륭한 하루였어요.',
      '조금만 더 했더라면? 아니, 이미 충분히 잘했어요.',
      '과정 하나하나를 잘 걸어온 하루예요.',
    ],
    this.exitMsgHigh = const [
      '거의 다 해냈어요! 오늘의 나는 정말 멋졌어요.',
      '충분히 열심히 했어요. 이제는 쉬어도 돼요.',
      '해야 할 일을 거의 마무리했어요. 대단해요.',
    ],
    this.exitMsgPerfect = const [
      '오늘 해야 할 일을 전부 해냈어요! 완벽한 하루!',
      '스스로 자랑스러워도 돼요. 정말 최고예요.',
      '목표를 모두 달성한 멋진 하루였어요.',
    ],
    this.exitMsgNoDaily = const [
      '오늘은 목록이 없어도 괜찮아요. 그런 날도 필요해요.',
      '계획이 없어도 의미 있는 하루였어요.',
      '오늘도 잘 버텨왔어요. 그것만으로 충분해요.',
    ],

    this.backgroundImages = const {},
    this.backgroundOpacity = const {},
    this.backgroundBlur = const {},
  });

  AppSettings copyWith({
    bool? notificationsEnabled,
    bool? vibrationEnabled,
    String? notificationSound,
    String? vibrationMode,
    String? theme,
    String? defaultScheduleColorHex,
    bool? dailyEnabled,
    String? startTabId,
    List<String>? exitMsgZero,
    List<String>? exitMsgLow,
    List<String>? exitMsgMid,
    List<String>? exitMsgHigh,
    List<String>? exitMsgPerfect,
    List<String>? exitMsgNoDaily,
    Map<String, String?>? backgroundImages,
    Map<String, double>? backgroundOpacity,
    Map<String, double>? backgroundBlur,
  }) {
    return AppSettings(
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
      vibrationEnabled: vibrationEnabled ?? this.vibrationEnabled,
      notificationSound: notificationSound ?? this.notificationSound,
      vibrationMode: vibrationMode ?? this.vibrationMode,
      theme: theme ?? this.theme,
      defaultScheduleColorHex:
          defaultScheduleColorHex ?? this.defaultScheduleColorHex,
      dailyEnabled: dailyEnabled ?? this.dailyEnabled,
      startTabId: startTabId ?? this.startTabId,
      exitMsgZero: exitMsgZero ?? this.exitMsgZero,
      exitMsgLow: exitMsgLow ?? this.exitMsgLow,
      exitMsgMid: exitMsgMid ?? this.exitMsgMid,
      exitMsgHigh: exitMsgHigh ?? this.exitMsgHigh,
      exitMsgPerfect: exitMsgPerfect ?? this.exitMsgPerfect,
      exitMsgNoDaily: exitMsgNoDaily ?? this.exitMsgNoDaily,
      backgroundImages: backgroundImages ?? this.backgroundImages,
      backgroundOpacity: backgroundOpacity ?? this.backgroundOpacity,
      backgroundBlur: backgroundBlur ?? this.backgroundBlur,
    );
  }

  factory AppSettings.fromJson(Map<String, dynamic> json) {
    List<String> _readList(String key) {
      final v = json[key];
      if (v is List) {
        return v.map((e) => e.toString()).toList();
      }
      return const [];
    }

    Map<String, String?> _readStringMap(String key) {
      final v = json[key];
      if (v is Map) {
        return v.map((k, value) => MapEntry(k.toString(), value as String?));
      }
      return const {};
    }

    Map<String, double> _readDoubleMap(String key) {
      final v = json[key];
      if (v is Map) {
        return v.map((k, value) {
          if (value is num) return MapEntry(k.toString(), value.toDouble());
          return MapEntry(k.toString(), 0.0);
        });
      }
      return const {};
    }

    return AppSettings(
      notificationsEnabled: json['notificationsEnabled'] ?? true,
      vibrationEnabled: json['vibrationEnabled'] ?? true,
      notificationSound: json['notificationSound'] ?? 'default',
      vibrationMode: json['vibrationMode'] ?? 'normal',
      theme: json['theme'] ?? 'default',
      defaultScheduleColorHex:
          json['defaultScheduleColorHex'] ?? '#4ecdc4',
      dailyEnabled: json['dailyEnabled'] ?? true,
      startTabId: json['startTabId'] ?? 'table',
      exitMsgZero: _readList('exitMsgZero'),
      exitMsgLow: _readList('exitMsgLow'),
      exitMsgMid: _readList('exitMsgMid'),
      exitMsgHigh: _readList('exitMsgHigh'),
      exitMsgPerfect: _readList('exitMsgPerfect'),
      exitMsgNoDaily: _readList('exitMsgNoDaily'),
      backgroundImages: _readStringMap('backgroundImages'),
      backgroundOpacity: _readDoubleMap('backgroundOpacity'),
      backgroundBlur: _readDoubleMap('backgroundBlur'),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'notificationsEnabled': notificationsEnabled,
      'vibrationEnabled': vibrationEnabled,
      'notificationSound': notificationSound,
      'vibrationMode': vibrationMode,
      'theme': theme,
      'defaultScheduleColorHex': defaultScheduleColorHex,
      'dailyEnabled': dailyEnabled,
      'startTabId': startTabId,
      'exitMsgZero': exitMsgZero,
      'exitMsgLow': exitMsgLow,
      'exitMsgMid': exitMsgMid,
      'exitMsgHigh': exitMsgHigh,
      'exitMsgPerfect': exitMsgPerfect,
      'exitMsgNoDaily': exitMsgNoDaily,
      'backgroundImages': backgroundImages,
      'backgroundOpacity': backgroundOpacity,
      'backgroundBlur': backgroundBlur,
    };
  }
}
