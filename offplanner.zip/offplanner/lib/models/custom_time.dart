class CustomTime {
  final int totalMinutes;

  const CustomTime(this.totalMinutes)
      : assert(totalMinutes >= 0 && totalMinutes <= 1440);

  factory CustomTime.h(int hour, int minute) {
    final total = hour * 60 + minute;
    return CustomTime(total.clamp(0, 1440));
  }

  int get hour => totalMinutes ~/ 60;
  int get minute => totalMinutes % 60;

  bool get isMidnight24 => totalMinutes == 1440;

  String format() {
    if (isMidnight24) return '24:00';
    return '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';
  }

  @override
  String toString() => format();
}
