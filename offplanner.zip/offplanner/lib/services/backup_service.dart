// lib/services/backup_service.dart
import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import 'package:offplanner/models/schedule_item.dart';
import 'package:offplanner/models/dday_item.dart';
import 'package:offplanner/providers/app_settings_provider.dart';
import 'package:offplanner/providers/schedule_provider.dart';
import 'package:offplanner/providers/dday_provider.dart';
import 'package:offplanner/providers/daily_task_provider.dart';

class BackupService {
  BackupService._internal();
  static final BackupService _instance = BackupService._internal();
  factory BackupService() => _instance;

  /// ====== 1. 전체 데이터를 JSON 문자열로 만드는 함수 ======
  Future<String> buildBackupJson({
    required AppSettingsProvider appSettingsProv,
    required ScheduleProvider scheduleProv,
    required DDayProvider ddayProv,
    required DailyTaskProvider dailyProv,
  }) async {
    final settings = appSettingsProv.settings;

    final appSettingsJson = {
      'notificationsEnabled': settings.notificationsEnabled,
      'vibrationEnabled': settings.vibrationEnabled,
      'notificationSound': settings.notificationSound,
      'theme': settings.theme,
      'defaultScheduleColorHex': settings.defaultScheduleColorHex,
    };

    final schedulesJson = scheduleProv.allItems
        .map((e) => e.toJson())
        .toList(growable: false);

    final ddayJson = ddayProv.allItems
        .map((d) => {
              'id': d.id,
              'title': d.title,
              'targetDate': d.targetDate.toIso8601String(),
              'colorHex': d.colorHex,
              'isActive': d.isActive,
            })
        .toList(growable: false);

    final dailyJson = _exportDailyTasks(dailyProv);

    final backupMap = {
      'version': 1,
      'createdAt': DateTime.now().toIso8601String(),
      'appSettings': appSettingsJson,
      'schedules': schedulesJson,
      'ddays': ddayJson,
      'dailyTasks': dailyJson,
    };

    const encoder = JsonEncoder.withIndent('  ');
    return encoder.convert(backupMap);
  }

  /// DailyTaskProvider → JSON용 리스트로 변환
  List<Map<String, dynamic>> _exportDailyTasks(DailyTaskProvider dailyProv) {
    final result = <Map<String, dynamic>>[];

    // ±365일만 백업 (필요하면 늘려도 됨)
    final now = DateTime.now();
    var day = DateTime(now.year, now.month, now.day)
        .subtract(const Duration(days: 365));
    final end = DateTime(now.year, now.month, now.day)
        .add(const Duration(days: 365));

    while (!day.isAfter(end)) {
      final tasks = dailyProv.tasksForDate(day);
      if (tasks.isNotEmpty) {
        for (final t in tasks) {
          result.add({
            'date': DateTime(day.year, day.month, day.day)
                .toIso8601String(),
            'title': t.title,
            'done': t.isDone,
          });
        }
      }
      day = day.add(const Duration(days: 1));
    }

    return result;
  }

  /// ====== 2. JSON 문자열로부터 전체 데이터 복원 ======
  Future<void> restoreFromBackupJson(
    String json, {
    required AppSettingsProvider appSettingsProv,
    required ScheduleProvider scheduleProv,
    required DDayProvider ddayProv,
    required DailyTaskProvider dailyProv,
  }) async {
    final decoded = jsonDecode(json);
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('올바르지 않은 백업 형식입니다.');
    }

    // === 앱 설정 복원 ===
    final settingsMap =
        decoded['appSettings'] as Map<String, dynamic>?;

    if (settingsMap != null) {
      appSettingsProv.setNotificationsEnabled(
        settingsMap['notificationsEnabled'] as bool? ?? true,
      );
      appSettingsProv.setVibrationEnabled(
        settingsMap['vibrationEnabled'] as bool? ?? true,
      );
      appSettingsProv.setNotificationSound(
        settingsMap['notificationSound'] as String? ?? 'default',
      );
      appSettingsProv.setTheme(
        settingsMap['theme'] as String? ?? 'default',
      );
      appSettingsProv.setDefaultScheduleColor(
        settingsMap['defaultScheduleColorHex'] as String? ??
            '#4ecdc4',
      );
    }

    // === 일정 복원 ===
    final schedulesList = decoded['schedules'] as List? ?? [];
    await scheduleProv.clearAll();
    for (final item in schedulesList) {
      if (item is! Map<String, dynamic>) continue;
      try {
        final schedule = ScheduleItem.fromJson(item);
        scheduleProv.addSchedule(schedule);
      } catch (_) {
        // 개별 항목 에러는 무시
      }
    }

    // === D-Day 복원 ===
    final ddayList = decoded['ddays'] as List? ?? [];
    ddayProv.clearAll();
    for (final item in ddayList) {
      if (item is! Map<String, dynamic>) continue;
      try {
        final targetDateStr = item['targetDate'] as String?;
        final targetDate =
            DateTime.tryParse(targetDateStr ?? '') ?? DateTime.now();
        final dday = DDayItem(
          id: item['id'] as String? ?? '',
          title: item['title'] as String? ?? '',
          targetDate: targetDate,
          colorHex: item['colorHex'] as String? ?? '#e63946',
          isActive: item['isActive'] as bool? ?? true,
        );
        ddayProv.addDDay(dday);
      } catch (_) {
        // 개별 항목 에러는 무시
      }
    }

    // === 데일리 할 일 복원 ===
    final dailyList = decoded['dailyTasks'] as List? ?? [];
    await _restoreDailyTasks(dailyProv, dailyList);
  }

  Future<void> _restoreDailyTasks(
    DailyTaskProvider dailyProv,
    List<dynamic> dailyList,
  ) async {
    if (dailyList.isEmpty) return;

    final items = <_BackupDailyTask>[];

    for (final raw in dailyList) {
      if (raw is! Map<String, dynamic>) continue;
      final dateStr = raw['date'] as String?;
      final title = (raw['title'] as String? ?? '').trim();
      final done = raw['done'] as bool? ?? false;

      if (dateStr == null || title.isEmpty) continue;

      final parsed = DateTime.tryParse(dateStr);
      if (parsed == null) continue;

      items.add(
        _BackupDailyTask(
          date: DateTime(parsed.year, parsed.month, parsed.day),
          title: title,
          done: done,
        ),
      );
    }

    if (items.isEmpty) return;

    // 정렬 후 기존 데이터 제거 범위 계산
    items.sort((a, b) => a.date.compareTo(b.date));
    final firstDay = items.first.date;
    final lastDay = items.last.date;

    // 기존 데이터 삭제 (백업 범위 안에서만)
    var day = firstDay;
    while (!day.isAfter(lastDay)) {
      final tasks = dailyProv.tasksForDate(day);
      for (final t in List.of(tasks)) {
        dailyProv.removeTask(day, t.id);
      }
      day = day.add(const Duration(days: 1));
    }

    // 백업 데이터 재삽입
    for (final item in items) {
      final date = item.date;

      final beforeIds =
          dailyProv.tasksForDate(date).map((e) => e.id).toSet();

      dailyProv.addTask(date, item.title);

      if (item.done) {
        final afterList = dailyProv.tasksForDate(date);
        String? newId;
        for (final t in afterList) {
          if (!beforeIds.contains(t.id)) {
            newId = t.id;
            break;
          }
        }
        if (newId != null) {
          dailyProv.toggleTask(date, newId);
        }
      }
    }
  }

  /// ====== 3. JSON을 실제 파일로 내보내기 ======
  ///
  /// 안드로이드: /storage/emulated/0/Download/offplanner_backup_YYYYMMDD_HHMMSS.json
  /// iOS/기타:   앱 문서 디렉토리 안에 저장
  Future<File> exportToFile({
    required AppSettingsProvider appSettingsProv,
    required ScheduleProvider scheduleProv,
    required DDayProvider ddayProv,
    required DailyTaskProvider dailyProv,
  }) async {
    final json = await buildBackupJson(
      appSettingsProv: appSettingsProv,
      scheduleProv: scheduleProv,
      ddayProv: ddayProv,
      dailyProv: dailyProv,
    );

    Directory dir;

    if (Platform.isAndroid) {
      // 안드로이드: 공개 다운로드 폴더를 우선 사용
      final downloadDir = Directory('/storage/emulated/0/Download');
      if (await downloadDir.exists()) {
        dir = downloadDir;
      } else {
        // 혹시 위 경로가 없으면 앱 문서 디렉토리로 폴백
        dir = await getApplicationDocumentsDirectory();
      }
    } else {
      // iOS / 기타: 앱 문서 디렉토리
      dir = await getApplicationDocumentsDirectory();
    }

    final now = DateTime.now();
    final ts =
        '${now.year.toString().padLeft(4, '0')}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}_${now.hour.toString().padLeft(2, '0')}${now.minute.toString().padLeft(2, '0')}${now.second.toString().padLeft(2, '0')}';

    final fileName = 'offplanner_backup_$ts.json';
    final file = File('${dir.path}/$fileName');

    await file.writeAsString(json);

    return file;
  }

  /// ====== 4. 파일에서 읽어서 복원 ======
  Future<void> restoreFromFile(
    File file, {
    required AppSettingsProvider appSettingsProv,
    required ScheduleProvider scheduleProv,
    required DDayProvider ddayProv,
    required DailyTaskProvider dailyProv,
  }) async {
    final text = await file.readAsString();
    await restoreFromBackupJson(
      text,
      appSettingsProv: appSettingsProv,
      scheduleProv: scheduleProv,
      ddayProv: ddayProv,
      dailyProv: dailyProv,
    );
  }
}

class _BackupDailyTask {
  final DateTime date;
  final String title;
  final bool done;

  _BackupDailyTask({
    required this.date,
    required this.title,
    required this.done,
  });
}
