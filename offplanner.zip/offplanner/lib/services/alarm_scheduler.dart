// lib/services/alarm_scheduler.dart
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart';
import 'package:offplanner/services/notification_service.dart';
import 'package:vibration/vibration.dart';

class AlarmScheduler {
  AlarmScheduler._();

  static final instance = AlarmScheduler._();

  /// 앱 시작 시 반드시 실행
  void init() {
    initializeTimeZones();
  }

  Future<void> scheduleAlarm({
    required String id,
    required DateTime dateTime,
    required String title,
    required String body,
    String? soundPath,   // mp3 path
    bool vibration = true,
  }) async {
    final notif = NotificationService.instance;

    // 기본 알람음 또는 사용자 mp3
    final sound = soundPath != null
        ? RawResourceAndroidNotificationSound(soundPath.split('/').last.split('.').first)
        : null;

    await notif.plugin.zonedSchedule(
      id.hashCode,
      title,
      body,
      tz.TZDateTime.from(dateTime, tz.local),
      NotificationDetails(
        android: AndroidNotificationDetails(
          'planner_alarm',
          'Planner Alarm',
          importance: Importance.max,
          priority: Priority.high,
          sound: sound,
          playSound: true,
          enableVibration: vibration,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.alarmClock,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  Future<void> cancelAlarm(String id) async {
    await NotificationService.instance.plugin.cancel(id.hashCode);
  }
}
