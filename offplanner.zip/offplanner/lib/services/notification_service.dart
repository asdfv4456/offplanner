// lib/services/notification_service.dart
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:shared_preferences/shared_preferences.dart';

import 'package:offplanner/models/schedule_item.dart';

/// 알림 탭 콜백 타입 (플러터 알림용)
typedef NotificationTapCallback = void Function(String? payload);

/// 🔔 알림 전담 서비스 (싱글톤)
class NotificationService {
  NotificationService._internal();
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  bool _initialized = false;

  // 클릭 콜백 (flutter_local_notifications → AlarmRingPage 이동용)
  NotificationTapCallback? _onTap;

  // 🔊/📳 조합별 채널 ID
  // 소리 ON/OFF × 진동 ON/OFF = 4개
  static const String _channelIdSoundOnVibOn =
      'offplanner_sound_on_vib_on';
  static const String _channelIdSoundOnVibOff =
      'offplanner_sound_on_vib_off';
  static const String _channelIdSoundOffVibOn =
      'offplanner_sound_off_vib_on';
  static const String _channelIdSoundOffVibOff =
      'offplanner_sound_off_vib_off';

  static const String _channelName = '일정 알림';
  static const String _channelDescription = 'OffPlanner 일정 알림 채널';

  // (옵션) 안드로이드 "정확한 알람" 권한 요청용 채널
  static const MethodChannel _permissionsChannel =
      MethodChannel('offplanner/permissions');

  /// 앱 시작 시 main.dart 에서 한 번 호출
  Future<void> init() async {
    if (_initialized) return;

    // 타임존 초기화 (예약 알림용)
    tz.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation('Asia/Seoul'));

    // 초기화 세팅
    const AndroidInitializationSettings androidInit =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const DarwinInitializationSettings darwinInit =
        DarwinInitializationSettings();

    const InitializationSettings initSettings = InitializationSettings(
      android: androidInit,
      iOS: darwinInit,
      macOS: darwinInit,
    );

    await _plugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        // ▶️ 앱이 살아 있을 때 / 포그라운드·백그라운드일 때 탭하면 여기로 옴
        handleNotificationResponse(response);
      },
      onDidReceiveBackgroundNotificationResponse: notificationTapBackground,
    );

    // 🔔 안드로이드용 채널 여러 개 생성 (소리 / 진동 조합)
    final androidImpl = _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();

    if (androidImpl != null && Platform.isAndroid) {
      // 소리 ON + 진동 ON
      await androidImpl.createNotificationChannel(
        const AndroidNotificationChannel(
          _channelIdSoundOnVibOn,
          '알림 (소리 + 진동)',
          description: _channelDescription,
          importance: Importance.max,
          playSound: true,
          enableVibration: true,
        ),
      );

      // 소리 ON + 진동 OFF
      await androidImpl.createNotificationChannel(
        const AndroidNotificationChannel(
          _channelIdSoundOnVibOff,
          '알림 (소리만)',
          description: _channelDescription,
          importance: Importance.max,
          playSound: true,
          enableVibration: false,
        ),
      );

      // 소리 OFF + 진동 ON
      await androidImpl.createNotificationChannel(
        const AndroidNotificationChannel(
          _channelIdSoundOffVibOn,
          '알림 (진동만)',
          description: _channelDescription,
          importance: Importance.max,
          playSound: false,
          enableVibration: true,
        ),
      );

      // 소리 OFF + 진동 OFF
      await androidImpl.createNotificationChannel(
        const AndroidNotificationChannel(
          _channelIdSoundOffVibOff,
          '알림 (무음)',
          description: _channelDescription,
          importance: Importance.max,
          playSound: false,
          enableVibration: false,
        ),
      );
    }

    _initialized = true;
  }

  /// 알림 탭 콜백 등록 (flutter_local_notifications → Flutter AlarmRingPage)
  void setOnNotificationTap(NotificationTapCallback callback) {
    _onTap = callback;
  }

  /// NotificationResponse 공통 처리 (포그라운드/백그라운드)
  void handleNotificationResponse(NotificationResponse response) {
    if (kDebugMode) {
      debugPrint('🔔 Notification tapped. payload = ${response.payload}');
    }

    final payload = response.payload;
    _onTap?.call(payload);
  }

  /// ✅ 앱이 "알림 때문에" 켜졌는지 확인 (cold start + full-screen 포함)
  Future<NotificationAppLaunchDetails?> getLaunchDetails() async {
    return await _plugin.getNotificationAppLaunchDetails();
  }

  /// ✅ Android 13+ 알림 권한 요청 헬퍼
  Future<bool> requestAndroidNotificationPermission() async {
    if (!Platform.isAndroid) {
      return true;
    }

    final androidImpl = _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();
    if (androidImpl == null) {
      return true;
    }

    // 이미 알림이 허용되어 있는지 확인
    final enabled = await androidImpl.areNotificationsEnabled();
    if (enabled == true) {
      return true;
    }

    // 런타임 권한 요청 (Android 13+)
    final granted = await androidImpl.requestNotificationsPermission();
    return granted ?? false;
  }

  /// (옵션) Android 12(S)+ "정확한 알람" 설정 화면 열기
  Future<bool> ensureExactAlarmPermissionOnAndroid() async {
    if (!Platform.isAndroid) return true;

    try {
      final result = await _permissionsChannel
          .invokeMethod<bool>('requestExactAlarmPermission');
      return result ?? false;
    } on PlatformException catch (e) {
      if (kDebugMode) {
        debugPrint('⚠️ exact alarm permission request failed: $e');
      }
      return false;
    }
  }

  /// 🔧 SharedPreferences에서 현재 알림 설정 읽기
  /// - notificationSound: 'default' / 'none'
  /// - vibrationEnabled: true / false
  Future<Map<String, dynamic>> _loadAlarmConfig() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('app_settings');
      if (raw == null) {
        return {
          'soundId': 'default',
          'vibrationEnabled': true,
        };
      }
      final map = jsonDecode(raw) as Map<String, dynamic>;
      final soundId = map['notificationSound'] as String? ?? 'default';
      final vib = map['vibrationEnabled'] as bool? ?? true;
      return {
        'soundId': soundId,
        'vibrationEnabled': vib,
      };
    } catch (_) {
      return {
        'soundId': 'default',
        'vibrationEnabled': true,
      };
    }
  }

  /// 내부용: 소리/진동 설정에 맞는 AndroidNotificationDetails 생성
  /// 🔥 fullScreenIntent + ALARM 카테고리 설정 (진짜 알람처럼)
  AndroidNotificationDetails _buildAndroidDetails(
    String soundId,
    bool vibrationEnabled,
  ) {
    // (웹 등) 안드로이드가 아닐 때는 그냥 기본 값
    if (!Platform.isAndroid) {
      return const AndroidNotificationDetails(
        'offplanner_default',
        '일정 알림',
        channelDescription: 'OffPlanner 일정 알림',
        importance: Importance.max,
        priority: Priority.high,
        category: AndroidNotificationCategory.alarm,
        fullScreenIntent: true,
      );
    }

    String channelId;
    if (soundId == 'none') {
      // 소리 OFF
      channelId = vibrationEnabled
          ? _channelIdSoundOffVibOn
          : _channelIdSoundOffVibOff;
    } else {
      // 소리 ON (기본 알림음)
      channelId = vibrationEnabled
          ? _channelIdSoundOnVibOn
          : _channelIdSoundOnVibOff;
    }

    return AndroidNotificationDetails(
      channelId,
      _channelName,
      channelDescription: _channelDescription,
      importance: Importance.max,
      priority: Priority.high,
      category: AndroidNotificationCategory.alarm,
      fullScreenIntent: true, // 🔥 화면을 깨워서 전체 알람으로 띄우도록 요청
    );
  }

  /// 🔔 테스트 알림 (바로 울리는 버전)
  ///
  /// SettingsTab에서:
  /// await NotificationService().showTestNotification(
  ///   s.notificationSound,
  ///   s.vibrationEnabled,
  /// );
  Future<void> showTestNotification(
    String soundId,
    bool vibrationEnabled,
  ) async {
    // Android 13+ 에서 권한 없으면 먼저 요청
    if (Platform.isAndroid) {
      final ok = await requestAndroidNotificationPermission();
      if (!ok) {
        if (kDebugMode) {
          debugPrint('🚫 Notification permission not granted on Android.');
        }
      }
    }

    final androidDetails = _buildAndroidDetails(soundId, vibrationEnabled);
    final details = NotificationDetails(android: androidDetails);

    await _plugin.show(
      0,
      '테스트 알림',
      'OffPlanner 알림이 정상 동작합니다.',
      details,
      payload: jsonEncode({
        'type': 'test',
        'title': '테스트 알림',
        'body': 'OffPlanner 알림이 정상 동작합니다.',
      }),
    );
  }

  /// ScheduleItem 하나에 대한 고유 알림 ID 생성
  int _idForSchedule(ScheduleItem item) {
    // 일정 id를 기반으로 고유한 int ID 생성
    return item.id.hashCode & 0x7fffffff;
  }

  /// ⏰ 일정 기반 알림 예약 (flutter_local_notifications 사용)
  ///
  /// - 앱이 꺼져 있어도 OS가 알아서 알림을 띄움
  Future<void> scheduleForScheduleItem(ScheduleItem item) async {
    if (!item.alarmEnabled) {
      return;
    }

    // 안드로이드 권한 확인
    if (Platform.isAndroid) {
      final ok = await requestAndroidNotificationPermission();
      if (!ok) return;
    }

    // 현재 저장된 알림 설정 읽기
    final config = await _loadAlarmConfig();
    final soundId = config['soundId'] as String;
    final vibrationEnabled = config['vibrationEnabled'] as bool;

    final scheduledDateTime = DateTime(
      item.date.year,
      item.date.month,
      item.date.day,
      item.start.hour,
      item.start.minute,
    );

    final now = DateTime.now();
    final adjustedDateTime = scheduledDateTime.isBefore(now)
        ? now.add(const Duration(seconds: 1))
        : scheduledDateTime;

    final tzTime = tz.TZDateTime.from(adjustedDateTime, tz.local);

    final androidDetails = _buildAndroidDetails(soundId, vibrationEnabled);
    final details = NotificationDetails(android: androidDetails);

    final id = _idForSchedule(item);

    final payload = jsonEncode({
      'type': 'schedule',
      'scheduleId': item.id,
      'title': item.title,
      'body': '${item.start.format()} ~ ${item.end.format()}',
    });

    try {
      await _plugin.zonedSchedule(
        id,
        item.title,
        '${item.start.format()} ~ ${item.end.format()}',
        tzTime,
        details,
        // exact 대신 inexact (권한 이슈 피하기)
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        androidAllowWhileIdle: true,
        payload: payload,
      );

      if (kDebugMode) {
        debugPrint(
            '⏰ scheduleForScheduleItem → zonedSchedule: id=$id, time=$adjustedDateTime');
      }
    } on PlatformException catch (e) {
      if (kDebugMode) {
        debugPrint('❌ zonedSchedule (scheduleForScheduleItem) 실패: $e');
      }
    } catch (e) {
      if (kDebugMode) {
        debugPrint('❌ zonedSchedule (scheduleForScheduleItem) 기타 오류: $e');
      }
    }
  }

  /// ⏰ 5분 뒤 다시 알림(스누즈) — AlarmRingPage에서 사용
  ///
  /// AlarmRingPage에서:
  /// await NotificationService().scheduleSnooze(
  ///   title: title,
  ///   body: body,
  ///   soundId: settings.notificationSound,
  ///   vibrationEnabled: settings.vibrationEnabled,
  /// );
  Future<void> scheduleSnooze({
    required String title,
    required String body,
    Duration delay = const Duration(minutes: 5),
    String soundId = 'default',
    bool vibrationEnabled = true,
  }) async {
    if (Platform.isAndroid) {
      final ok = await requestAndroidNotificationPermission();
      if (!ok) return;
    }

    final scheduled = DateTime.now().add(delay);
    final tzTime = tz.TZDateTime.from(scheduled, tz.local);

    final androidDetails = _buildAndroidDetails(soundId, vibrationEnabled);
    final details = NotificationDetails(android: androidDetails);

    // 스누즈용 ID는 고유하게 타임스탬프 기반 사용
    final id = DateTime.now().millisecondsSinceEpoch & 0x7fffffff;

    try {
      await _plugin.zonedSchedule(
        id,
        title,
        body,
        tzTime,
        details,
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        androidAllowWhileIdle: true,
        payload: jsonEncode({
          'type': 'snooze',
          'title': title,
          'body': body,
        }),
      );

      if (kDebugMode) {
        debugPrint('⏰ scheduleSnooze → zonedSchedule: id=$id, time=$scheduled');
      }
    } on PlatformException catch (e) {
      if (kDebugMode) {
        debugPrint('❌ zonedSchedule (scheduleSnooze) 실패: $e');
      }
    } catch (e) {
      if (kDebugMode) {
        debugPrint('❌ zonedSchedule (scheduleSnooze) 기타 오류: $e');
      }
    }
  }

  /// ⏹ 일정 기반 알림 취소
  Future<void> cancelForScheduleItem(ScheduleItem item) async {
    final id = _idForSchedule(item);

    try {
      await _plugin.cancel(id);

      if (kDebugMode) {
        debugPrint('🛑 cancelForScheduleItem → cancel: id=$id');
      }
    } on PlatformException catch (e) {
      // ⚠️ 일부 기기/버전에서 "Missing type parameter" 같은 예외가 나올 수 있음.
      //    이때 앱이 죽지 않도록 로그만 남기고 무시.
      if (kDebugMode) {
        debugPrint('⚠️ cancelForScheduleItem PlatformException: $e');
      }
    } catch (e) {
      if (kDebugMode) {
        debugPrint('⚠️ cancelForScheduleItem 기타 오류: $e');
      }
    }
  }

  FlutterLocalNotificationsPlugin get plugin => _plugin;
}

/// 🔁 백그라운드에서 알림을 눌렀을 때 호출되는 엔트리 포인트
@pragma('vm:entry-point')
void notificationTapBackground(NotificationResponse response) {
  if (kDebugMode) {
    debugPrint(
        '🔔 [background] notification tapped (payload: ${response.payload})');
  }
}
