// lib/services/notification_service.dart
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:shared_preferences/shared_preferences.dart';

import 'package:offplanner/models/schedule_item.dart';

typedef NotificationTapCallback = void Function(String? payload);

class NotificationService {
  NotificationService._internal();
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  bool _initialized = false;

  NotificationTapCallback? _onTap;

  static const String _channelIdSoundOnVibOn =
      'offplanner_sound_on_vib_on';
  static const String _channelIdSoundOnVibOff =
      'offplanner_sound_on_vib_off';
  static const String _channelIdSoundOffVibOn =
      'offplanner_sound_off_vib_on';
  static const String _channelIdSoundOffVibOff =
      'offplanner_sound_off_vib_off';

  static const String _channelName = '일정 알림';
  static const String _channelDescription = 'OffPlanner 일정 알림 채널';

  static const MethodChannel _permissionsChannel =
      MethodChannel('offplanner/permissions');

  Future<void> init() async {
    if (_initialized) return;


    tz.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation('Asia/Seoul'));

    const AndroidInitializationSettings androidInit =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const DarwinInitializationSettings darwinInit =
        DarwinInitializationSettings();

    const InitializationSettings initSettings = InitializationSettings(
      android: androidInit,
      iOS: darwinInit,
      macOS: darwinInit,
    );

    await _plugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        handleNotificationResponse(response);
      },
      onDidReceiveBackgroundNotificationResponse: notificationTapBackground,
    );

    final androidImpl = _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();

    if (androidImpl != null && Platform.isAndroid) {

      await androidImpl.createNotificationChannel(
        const AndroidNotificationChannel(
          _channelIdSoundOnVibOn,
          '알림 (소리 + 진동)',
          description: _channelDescription,
          importance: Importance.max,
          playSound: true,
          enableVibration: true,
        ),
      );


      await androidImpl.createNotificationChannel(
        const AndroidNotificationChannel(
          _channelIdSoundOnVibOff,
          '알림 (소리만)',
          description: _channelDescription,
          importance: Importance.max,
          playSound: true,
          enableVibration: false,
        ),
      );


      await androidImpl.createNotificationChannel(
        const AndroidNotificationChannel(
          _channelIdSoundOffVibOn,
          '알림 (진동만)',
          description: _channelDescription,
          importance: Importance.max,
          playSound: false,
          enableVibration: true,
        ),
      );


      await androidImpl.createNotificationChannel(
        const AndroidNotificationChannel(
          _channelIdSoundOffVibOff,
          '알림 (무음)',
          description: _channelDescription,
          importance: Importance.max,
          playSound: false,
          enableVibration: false,
        ),
      );
    }

    _initialized = true;
  }

  void setOnNotificationTap(NotificationTapCallback callback) {
    _onTap = callback;
  }

  void handleNotificationResponse(NotificationResponse response) {
    if (kDebugMode) {
      debugPrint(' Notification tapped. payload = ${response.payload}');
    }

    final payload = response.payload;
    _onTap?.call(payload);
  }

  Future<NotificationAppLaunchDetails?> getLaunchDetails() async {
    return await _plugin.getNotificationAppLaunchDetails();
  }


  Future<bool> requestAndroidNotificationPermission() async {
    if (!Platform.isAndroid) {
      return true;
    }

    final androidImpl = _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();
    if (androidImpl == null) {
      return true;
    }

    final enabled = await androidImpl.areNotificationsEnabled();
    if (enabled == true) {
      return true;
    }

    try {
      final granted = await androidImpl.requestNotificationsPermission();
      return granted ?? false;
    } on PlatformException catch (e) {

      if (kDebugMode) {
        debugPrint(
          '⚠️ requestAndroidNotificationPermission error: $e',
        );
      }

      return true;
    }
  }


  Future<bool> ensureExactAlarmPermissionOnAndroid() async {
    if (!Platform.isAndroid) return true;

    try {
      final result = await _permissionsChannel
          .invokeMethod<bool>('requestExactAlarmPermission');
      if (kDebugMode) {
        debugPrint(' exact alarm permission result: $result');
      }
      return result ?? false;
    } on PlatformException catch (e) {
      if (kDebugMode) {
        debugPrint(' exact alarm permission request failed: $e');
      }
      return false;
    }
  }

  Future<Map<String, dynamic>> _loadAlarmConfig() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('app_settings');
      if (raw == null) {
        return {
          'soundId': 'default',
          'vibrationEnabled': true,
        };
      }
      final map = jsonDecode(raw) as Map<String, dynamic>;
      final soundId = map['notificationSound'] as String? ?? 'default';
      final vib = map['vibrationEnabled'] as bool? ?? true;
      return {
        'soundId': soundId,
        'vibrationEnabled': vib,
      };
    } catch (_) {
      return {
        'soundId': 'default',
        'vibrationEnabled': true,
      };
    }
  }

  AndroidNotificationDetails _buildAndroidDetails(
    String soundId,
    bool vibrationEnabled,
  ) {
    if (!Platform.isAndroid) {
      return const AndroidNotificationDetails(
        'offplanner_default',
        '일정 알림',
        channelDescription: 'OffPlanner 일정 알림',
        importance: Importance.max,
        priority: Priority.high,
        category: AndroidNotificationCategory.alarm,
        fullScreenIntent: true,
      );
    }

    String channelId;
    if (soundId == 'none') {
      channelId = vibrationEnabled
          ? _channelIdSoundOffVibOn
          : _channelIdSoundOffVibOff;
    } else {
      channelId = vibrationEnabled
          ? _channelIdSoundOnVibOn
          : _channelIdSoundOnVibOff;
    }

    return AndroidNotificationDetails(
      channelId,
      _channelName,
      channelDescription: _channelDescription,
      importance: Importance.max,
      priority: Priority.high,
      category: AndroidNotificationCategory.alarm,
      fullScreenIntent: true,
    );
  }


  Future<void> showTestNotification(
    String soundId,
    bool vibrationEnabled,
  ) async {
    if (Platform.isAndroid) {
      try {
        final ok = await requestAndroidNotificationPermission();
        if (!ok) {
          if (kDebugMode) {
            debugPrint(' Notification permission not granted on Android.');
          }
        }
      } catch (e) {
        if (kDebugMode) {
          debugPrint(' showTestNotification permission error: $e');
        }
      }
    }

    final androidDetails = _buildAndroidDetails(soundId, vibrationEnabled);
    final details = NotificationDetails(android: androidDetails);

    await _plugin.show(
      0,
      '테스트 알림',
      'OffPlanner 알림이 정상 동작합니다.',
      details,
      payload: jsonEncode({
        'type': 'test',
        'title': '테스트 알림',
        'body': 'OffPlanner 알림이 정상 동작합니다.',
      }),
    );
  }

  int _idForSchedule(ScheduleItem item) {
    return item.id.hashCode & 0x7fffffff;
  }

  Future<void> scheduleForScheduleItem(ScheduleItem item) async {
    if (!item.alarmEnabled) {
      return;
    }

    if (Platform.isAndroid) {
      try {
        final ok = await requestAndroidNotificationPermission();
        if (!ok) return;
      } catch (e) {
        if (kDebugMode) {
          debugPrint(' scheduleForScheduleItem permission error: $e');
        }
      }
    }

    final config = await _loadAlarmConfig();
    final soundId = config['soundId'] as String;
    final vibrationEnabled = config['vibrationEnabled'] as bool;

    final scheduledDateTime = DateTime(
      item.date.year,
      item.date.month,
      item.date.day,
      item.start.hour,
      item.start.minute,
    );

    final now = DateTime.now();
    final adjustedDateTime = scheduledDateTime.isBefore(now)
        ? now.add(const Duration(seconds: 1))
        : scheduledDateTime;

    final tzTime = tz.TZDateTime.from(adjustedDateTime, tz.local);

    final androidDetails = _buildAndroidDetails(soundId, vibrationEnabled);
    final details = NotificationDetails(android: androidDetails);

    final id = _idForSchedule(item);

    final payload = jsonEncode({
      'type': 'schedule',
      'scheduleId': item.id,
      'title': item.title,
      'body': '${item.start.format()} ~ ${item.end.format()}',
    });

    AndroidScheduleMode mode = AndroidScheduleMode.inexactAllowWhileIdle;

    if (Platform.isAndroid) {
      final exactOk = await ensureExactAlarmPermissionOnAndroid();
      if (exactOk) {
        mode = AndroidScheduleMode.exactAllowWhileIdle;
      } else {
        if (kDebugMode) {
          debugPrint(
            ' exact alarm permission not granted → using inexactAllowWhileIdle',
          );
        }
      }
    }

    try {
      await _plugin.zonedSchedule(
        id,
        item.title,
        '${item.start.format()} ~ ${item.end.format()}',
        tzTime,
        details,
        androidScheduleMode: mode,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        androidAllowWhileIdle: true,
        payload: payload,
      );

      if (kDebugMode) {
        debugPrint(
          ' scheduleForScheduleItem → zonedSchedule: id=$id, time=$adjustedDateTime, mode=$mode',
        );
      }
    } on PlatformException catch (e) {
      if (kDebugMode) {
        debugPrint(' zonedSchedule (scheduleForScheduleItem) 실패: $e');
      }
    } catch (e) {
      if (kDebugMode) {
        debugPrint(' zonedSchedule (scheduleForScheduleItem) 기타 오류: $e');
      }
    }
  }


  Future<void> scheduleSnooze({
    required String title,
    required String body,
    Duration delay = const Duration(minutes: 5),
    String soundId = 'default',
    bool vibrationEnabled = true,
  }) async {
    if (Platform.isAndroid) {
      try {
        final ok = await requestAndroidNotificationPermission();
        if (!ok) return;
      } catch (e) {
        if (kDebugMode) {
          debugPrint(' scheduleSnooze permission error: $e');
        }
      }
    }

    final scheduled = DateTime.now().add(delay);
    final tzTime = tz.TZDateTime.from(scheduled, tz.local);

    final androidDetails = _buildAndroidDetails(soundId, vibrationEnabled);
    final details = NotificationDetails(android: androidDetails);

    final id = DateTime.now().millisecondsSinceEpoch & 0x7fffffff;

    const AndroidScheduleMode mode =
        AndroidScheduleMode.inexactAllowWhileIdle;

    try {
      await _plugin.zonedSchedule(
        id,
        title,
        body,
        tzTime,
        details,
        androidScheduleMode: mode,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        androidAllowWhileIdle: true,
        payload: jsonEncode({
          'type': 'snooze',
          'title': title,
          'body': body,
        }),
      );

      if (kDebugMode) {
        debugPrint(' scheduleSnooze → zonedSchedule: id=$id, time=$scheduled');
      }
    } on PlatformException catch (e) {
      if (kDebugMode) {
        debugPrint(' zonedSchedule (scheduleSnooze) 실패: $e');
      }
    } catch (e) {
      if (kDebugMode) {
        debugPrint(' zonedSchedule (scheduleSnooze) 기타 오류: $e');
      }
    }
  }

  Future<void> cancelForScheduleItem(ScheduleItem item) async {
    final id = _idForSchedule(item);
    await _plugin.cancel(id);

    if (kDebugMode) {
      debugPrint('🗑 cancelForScheduleItem → cancel: id=$id');
    }
  }

  FlutterLocalNotificationsPlugin get plugin => _plugin;
}

@pragma('vm:entry-point')
void notificationTapBackground(NotificationResponse response) {
  if (kDebugMode) {
    debugPrint(
        ' [background] notification tapped (payload: ${response.payload})');
  }
}
