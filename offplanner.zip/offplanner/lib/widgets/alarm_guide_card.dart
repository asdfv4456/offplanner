// lib/widgets/alarm_guide_card.dart
import 'package:flutter/material.dart';

class AlarmGuideCard extends StatelessWidget {
  const AlarmGuideCard({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;

    return Card(
      color: cs.surfaceVariant.withOpacity(0.9),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '알람 사용 방법 안내',
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              '• 알람 시간이 되면 화면 전체에 알람 창이 뜹니다.\n'
              '• [5분 뒤에 다시 울리기] 버튼을 누르면 5분 후에 알람이 다시 울립니다.\n'
              '• 버튼을 누르지 않으면 알람은 한 번만 울립니다.\n'
              '• 알림 소리 / 진동은 아래 설정에서 변경할 수 있습니다.',
              style: theme.textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}
