// lib/widgets/dday_header.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:offplanner/providers/dday_provider.dart';

class DDayHeader extends StatefulWidget {
  const DDayHeader({super.key});

  @override
  State<DDayHeader> createState() => _DDayHeaderState();
}

class _DDayHeaderState extends State<DDayHeader> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    return Consumer<DDayProvider>(
      builder: (context, ddayProvider, child) {

        final allActive =
            ddayProvider.allItems.where((d) => d.isActive).toList();


        allActive.sort(
          (a, b) => a.targetDate.compareTo(b.targetDate),
        );


        if (allActive.isEmpty) {
          return const SizedBox.shrink();
        }

        return Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          color: Colors.grey.withOpacity(0.08),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    '다가오는 D-Day',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                  IconButton(
                    onPressed: () => setState(() => _expanded = !_expanded),
                    icon: Icon(
                      _expanded ? Icons.expand_less : Icons.expand_more,
                      size: 20,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),


              if (_expanded)
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: allActive.map((d) {
                    final days = _calcDDay(d.targetDate);
                    final dText = days >= 0 ? 'D-$days' : 'D+${days.abs()}';

                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2),
                      child: Row(
                        children: [
                          Container(
                            width: 8,
                            height: 8,
                            margin: const EdgeInsets.only(right: 8),
                            decoration: BoxDecoration(
                              color: _colorFromHex(d.colorHex),
                              shape: BoxShape.circle,
                            ),
                          ),
                          Expanded(
                            child: Text(
                              '$dText  ${d.title}',
                              style: const TextStyle(fontSize: 13),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
            ],
          ),
        );
      },
    );
  }

  int _calcDDay(DateTime target) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final t = DateTime(target.year, target.month, target.day);
    return t.difference(today).inDays;
  }

  Color _colorFromHex(String hex) {
    final buffer = StringBuffer();
    if (hex.length == 7 && hex.startsWith('#')) {
      buffer.write('ff');
      buffer.write(hex.replaceFirst('#', ''));
    } else if (hex.length == 9 && hex.startsWith('#')) {
      buffer.write(hex.replaceFirst('#', ''));
    } else {
      buffer.write('ff2196f3');
    }
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}
