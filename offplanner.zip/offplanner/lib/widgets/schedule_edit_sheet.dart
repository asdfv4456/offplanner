// lib/widgets/schedule_edit_sheet.dart
import 'package:flutter/material.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:provider/provider.dart';

import 'package:offplanner/models/schedule_item.dart';
import 'package:offplanner/models/custom_time.dart';
import 'package:offplanner/models/repeat_types.dart';

import 'package:offplanner/providers/schedule_provider.dart';
import 'package:offplanner/providers/dday_provider.dart';
import 'package:offplanner/providers/app_settings_provider.dart';

import 'package:offplanner/services/notification_service.dart';

class ScheduleEditSheet extends StatefulWidget {
  final DateTime? initialDate;
  final ScheduleItem? existing;

  final bool createDDayOnSave;

  const ScheduleEditSheet({
    super.key,
    this.initialDate,
    this.existing,
    this.createDDayOnSave = false,
  });

  @override
  State<ScheduleEditSheet> createState() => _ScheduleEditSheetState();
}

class _ScheduleEditSheetState extends State<ScheduleEditSheet> {
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _memoController = TextEditingController();

  late DateTime _selectedDate;
  late CustomTime _startTime;
  late CustomTime _endTime;

  bool _alarmEnabled = false;
  bool _soundEnabled = true;
  bool _vibrationEnabled = true;

  late Color _selectedColor;

  final List<Color> _colorOptions = const [
    Color(0xFFFFB3BA),
    Color(0xFFFFDFBA),
    Color(0xFFFFFFBA),
    Color(0xFFBAFFC9),
    Color(0xFFBAE1FF),
    Color(0xFFE7C6FF),
    Color(0xFFB5EAEA),
    Color(0xFFFFE5EC),
    Color(0xFFF9F1C6),
    Color(0xFFD7F9E9),
    Color(0xFFCDE7FF),
    Color(0xFFF8D1FF),
  ];

  bool get _isEditMode => widget.existing != null;

  RepeatType _repeatType = RepeatType.none;
  DateTime? _repeatEndDate;

  @override
  void initState() {
    super.initState();

    if (widget.existing != null) {
      final item = widget.existing!;
      _selectedDate = DateTime(item.date.year, item.date.month, item.date.day);
      _startTime = item.start;
      _endTime = item.end;
      _titleController.text = item.title;
      _memoController.text = item.memo ?? '';
      _alarmEnabled = item.alarmEnabled;
      _soundEnabled = item.soundEnabled;
      _vibrationEnabled = item.vibrationEnabled;
      _selectedColor = _colorFromHex(item.colorHex);

      _repeatType = RepeatType.none;
      _repeatEndDate = null;
    } else {
      final base = widget.initialDate ?? DateTime.now();
      _selectedDate = DateTime(base.year, base.month, base.day);
      _startTime = CustomTime.h(9, 0);
      _endTime = CustomTime.h(10, 0);

      final settings = context.read<AppSettingsProvider>().settings;
      _selectedColor = _colorFromHex(settings.defaultScheduleColorHex);
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _memoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;

    return SafeArea(
      top: false,
      child: Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: bottom + 16,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _isEditMode ? '일정 수정' : '일정 추가',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),

              TextField(
                controller: _titleController,
                decoration: const InputDecoration(
                  labelText: '제목',
                  border: OutlineInputBorder(),
                ),
              ),

              const SizedBox(height: 12),

              TextField(
                controller: _memoController,
                maxLines: 2,
                decoration: const InputDecoration(
                  labelText: '메모 (선택)',
                  border: OutlineInputBorder(),
                ),
              ),

              const SizedBox(height: 12),

              Row(
                children: [
                  const Text('날짜'),
                  const SizedBox(width: 16),
                  TextButton.icon(
                    onPressed: _pickDate,
                    icon:
                        const Icon(Icons.calendar_today_outlined, size: 18),
                    label: Text(
                      '${_selectedDate.year}년 ${_selectedDate.month}월 ${_selectedDate.day}일',
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 8),

              Row(
                children: [
                  Expanded(
                    child: _TimeField(
                      label: '시작',
                      value: _startTime.format(),
                      onTap: () async {
                        final result = await _pickCustomTime(_startTime);
                        if (result != null) {
                          setState(() {
                            _startTime = result;
                            if (!_isEndAfterStart()) {
                              final newEnd =
                                  _startTime.totalMinutes + 30;
                              final clamped = newEnd.clamp(
                                _startTime.totalMinutes + 1,
                                1440,
                              ) as int;
                              _endTime = CustomTime(clamped);
                            }
                          });
                        }
                      },
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _TimeField(
                      label: '끝',
                      value: _endTime.format(),
                      onTap: () async {
                        final result = await _pickCustomTime(_endTime);
                        if (result != null) {
                          setState(() => _endTime = result);
                        }
                      },
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 16),

              const Text(
                '색상',
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),

              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: [
                  ..._colorOptions.map((c) => _buildColorDot(c)),
                  GestureDetector(
                    onTap: _openCustomColorPicker,
                    child: Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.grey),
                      ),
                      child: const Icon(Icons.add, size: 20),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 16),

              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('알람 사용'),
                value: _alarmEnabled,
                onChanged: (v) => setState(() => _alarmEnabled = v),
              ),

              if (_alarmEnabled)
                Padding(
                  padding:
                      const EdgeInsets.only(left: 8, right: 8, bottom: 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: CheckboxListTile(
                          contentPadding: EdgeInsets.zero,
                          title: const Text('소리'),
                          value: _soundEnabled,
                          onChanged: (v) =>
                              setState(() => _soundEnabled = v ?? true),
                        ),
                      ),
                      Expanded(
                        child: CheckboxListTile(
                          contentPadding: EdgeInsets.zero,
                          title: const Text('진동'),
                          value: _vibrationEnabled,
                          onChanged: (v) => setState(
                              () => _vibrationEnabled = v ?? true),
                        ),
                      ),
                    ],
                  ),
                ),

              const SizedBox(height: 12),

              if (!_isEditMode) ...[
                const Divider(height: 24),
                const Text(
                  '반복',
                  style: TextStyle(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    DropdownButton<RepeatType>(
                      value: _repeatType,
                      items: const [
                        DropdownMenuItem(
                          value: RepeatType.none,
                          child: Text('반복 안함'),
                        ),
                        DropdownMenuItem(
                          value: RepeatType.daily,
                          child: Text('매일'),
                        ),
                        DropdownMenuItem(
                          value: RepeatType.weekly,
                          child: Text('매주'),
                        ),
                      ],
                      onChanged: (v) {
                        if (v == null) return;
                        setState(() {
                          _repeatType = v;
                          if (_repeatType == RepeatType.none) {
                            _repeatEndDate = null;
                          } else {
                            _repeatEndDate ??= _selectedDate;
                          }
                        });
                      },
                    ),
                    const SizedBox(width: 16),
                    if (_repeatType != RepeatType.none)
                      Expanded(
                        child: TextButton.icon(
                          onPressed: _pickRepeatEndDate,
                          icon: const Icon(Icons.date_range, size: 18),
                          label: Text(
                            _repeatEndDate == null
                                ? '종료 날짜 선택'
                                : '종료: ${_repeatEndDate!.year}.${_repeatEndDate!.month}.${_repeatEndDate!.day}',
                          ),
                        ),
                      ),
                  ],
                ),
                if (_repeatType != RepeatType.none)
                  const Padding(
                    padding: EdgeInsets.only(top: 6),
                    child: Text(
                      '※ 시작 날짜부터 종료 날짜까지, 겹치는 시간이 있으면 생성되지 않습니다.',
                      style:
                          TextStyle(fontSize: 11, color: Colors.grey),
                    ),
                  ),
              ],

              const SizedBox(height: 16),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (_isEditMode)
                    TextButton(
                      onPressed: _delete,
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.red,
                      ),
                      child: const Text('삭제'),
                    ),
                  const Spacer(),
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text('취소'),
                  ),
                  const SizedBox(width: 8),
                  ElevatedButton(
                    onPressed: _save,
                    child: Text(_isEditMode ? '수정' : '저장'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null) setState(() => _selectedDate = picked);
  }

  Future<void> _pickRepeatEndDate() async {
    final base = _repeatEndDate ?? _selectedDate;
    final picked = await showDatePicker(
      context: context,
      initialDate: base,
      firstDate: _selectedDate,
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() => _repeatEndDate = picked);
    }
  }

  bool _isEndAfterStart() {
    final start = _startTime.totalMinutes;
    final end = _endTime.totalMinutes;
    return end > start;
  }

  Future<CustomTime?> _pickCustomTime(CustomTime initial) async {
    return showModalBottomSheet<CustomTime>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => _CustomTimePicker(initial: initial),
    );
  }

  Widget _buildColorDot(Color c) {
    final selected = c.value == _selectedColor.value;
    return GestureDetector(
      onTap: () => setState(() => _selectedColor = c),
      child: Container(
        width: 28,
        height: 28,
        decoration: BoxDecoration(
          color: c,
          shape: BoxShape.circle,
          border: selected
              ? Border.all(color: Colors.black, width: 2)
              : null,
        ),
      ),
    );
  }

  Future<void> _openCustomColorPicker() async {
    Color temp = _selectedColor;

    await showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('색상 선택'),
          content: SingleChildScrollView(
            child: ColorPicker(
              pickerColor: temp,
              onColorChanged: (c) => temp = c,
              pickerAreaHeightPercent: 0.8,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('취소'),
            ),
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              child: const Text('적용'),
            ),
          ],
        );
      },
    ).then((value) {
      if (value == true) {
        setState(() {
          _selectedColor = temp;
        });
      }
    });
  }

  Future<void> _save() async {
    final title = _titleController.text.trim();
    if (title.isEmpty) {
      _showError('제목을 입력해 주세요.');
      return;
    }
    if (!_isEndAfterStart()) {
      _showError('끝나는 시간이 시작 시간보다 뒤여야 합니다.');
      return;
    }

    final scheduleProv = context.read<ScheduleProvider>();
    final appSettings = context.read<AppSettingsProvider>().settings;

    // ===== 수정 모드 =====
    if (_isEditMode) {
      final old = widget.existing!;

      final updated = ScheduleItem(
        id: old.id,
        title: title,
        memo: _memoController.text.trim().isEmpty
            ? null
            : _memoController.text.trim(),
        date: _selectedDate,
        start: _startTime,
        end: _endTime,
        colorHex: _colorToHex(_selectedColor),
        alarmEnabled: _alarmEnabled,
        soundEnabled: _soundEnabled,
        vibrationEnabled: _vibrationEnabled,
        repeatType: old.repeatType,
        repeatInterval: old.repeatInterval,
      );

      try {
        await scheduleProv.updateSchedule(updated);

        if (appSettings.notificationsEnabled && _alarmEnabled) {
          await NotificationService().scheduleForScheduleItem(updated);
        } else {
          await NotificationService().cancelForScheduleItem(updated);
        }

        if (mounted) Navigator.of(context).pop();
      } catch (e) {
        _showError(e.toString().replaceFirst('Exception: ', ''));
      }
      return;
    }

    // ===== 신규 + 반복 없음 =====
    if (_repeatType == RepeatType.none) {
      final item = ScheduleItem(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        title: title,
        memo: _memoController.text.trim().isEmpty
            ? null
            : _memoController.text.trim(),
        date: _selectedDate,
        start: _startTime,
        end: _endTime,
        colorHex: _colorToHex(_selectedColor),
        alarmEnabled: _alarmEnabled,
        soundEnabled: _soundEnabled,
        vibrationEnabled: _vibrationEnabled,
      );

      try {
        await scheduleProv.addSchedule(item);

        if (widget.createDDayOnSave) {
          final ddayProv = context.read<DDayProvider>();
          ddayProv.createFromSchedule(item);
        }

        if (appSettings.notificationsEnabled && _alarmEnabled) {
          await NotificationService().scheduleForScheduleItem(item);
        } else {
          await NotificationService().cancelForScheduleItem(item);
        }

        if (mounted) Navigator.of(context).pop();
      } catch (e) {
        _showError(e.toString().replaceFirst('Exception: ', ''));
      }
      return;
    }

    // ===== 신규 + 반복 있음 =====
    if (_repeatEndDate == null) {
      _showError('반복 종료 날짜를 선택해 주세요.');
      return;
    }
    if (_repeatEndDate!.isBefore(_selectedDate)) {
      _showError('종료 날짜는 시작 날짜 이후여야 합니다.');
      return;
    }

    final createdIds = <String>[];
    final dates = _buildRepeatDates(
      start: _selectedDate,
      end: _repeatEndDate!,
      type: _repeatType,
    );

    try {
      for (final d in dates) {
        final id = DateTime.now().microsecondsSinceEpoch.toString();
        final item = ScheduleItem(
          id: id,
          title: title,
          memo: _memoController.text.trim().isEmpty
              ? null
              : _memoController.text.trim(),
          date: d,
          start: _startTime,
          end: _endTime,
          colorHex: _colorToHex(_selectedColor),
          alarmEnabled: _alarmEnabled,
          soundEnabled: _soundEnabled,
          vibrationEnabled: _vibrationEnabled,
        );
        await scheduleProv.addSchedule(item);
        createdIds.add(id);

        if (appSettings.notificationsEnabled && _alarmEnabled) {
          await NotificationService().scheduleForScheduleItem(item);
        }
      }

      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      for (final id in createdIds) {
        await scheduleProv.deleteSchedule(id);
      }
      _showError(e.toString().replaceFirst('Exception: ', ''));
    }
  }

  void _delete() {
    final item = widget.existing!;
    final scheduleProv = context.read<ScheduleProvider>();
    final ddayProv = context.read<DDayProvider>();

    scheduleProv.deleteSchedule(item.id);
    ddayProv.removeByScheduleId(item.id);
    NotificationService().cancelForScheduleItem(item);

    Navigator.of(context).pop();
  }

  List<DateTime> _buildRepeatDates({
    required DateTime start,
    required DateTime end,
    required RepeatType type,
  }) {
    final List<DateTime> result = [];
    DateTime cur = DateTime(start.year, start.month, start.day);

    if (type == RepeatType.daily) {
      while (!cur.isAfter(end)) {
        result.add(cur);
        cur = cur.add(const Duration(days: 1));
      }
    } else if (type == RepeatType.weekly) {
      while (!cur.isAfter(end)) {
        result.add(cur);
        cur = cur.add(const Duration(days: 7));
      }
    } else {
      result.add(cur);
    }

    return result;
  }

  String _colorToHex(Color c) {
    return '#${c.red.toRadixString(16).padLeft(2, '0')}'
        '${c.green.toRadixString(16).padLeft(2, '0')}'
        '${c.blue.toRadixString(16).padLeft(2, '0')}';
  }

  // 🔻 여기만 진짜 중요: 어떤 이상한 값이 와도 앱 안 죽고 기본 색으로 처리
  Color _colorFromHex(String hex) {
    const fallback = Color(0xFF4ECDC4); // 기본 일정 색 (문제 있으면 여기만 바꾸면 됨)

    try {
      var clean = hex.trim();
      if (clean.isEmpty) {
        return fallback;
      }

      // "Color(0xff4ecdc4)" 형태로 저장된 경우
      if (clean.startsWith('Color(')) {
        final match = RegExp(r'0x[0-9a-fA-F]+').firstMatch(clean);
        if (match != null) {
          final value = int.parse(match.group(0)!, radix: 16);
          return Color(value);
        } else {
          return fallback;
        }
      }

      // 맨 앞에 # 없으면 붙이기
      if (!clean.startsWith('#')) {
        clean = '#$clean';
      }

      // #RRGGBB -> #AARRGGBB
      if (clean.length == 7) {
        clean = '#ff${clean.substring(1)}';
      }

      // #AARRGGBB
      if (clean.length == 9) {
        final value = int.parse(clean.substring(1), radix: 16);
        return Color(value);
      }

      return fallback;
    } catch (_) {
      return fallback;
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 2),
      ),
    );
  }
}

// ===== 시간 필드 위젯 =====
class _TimeField extends StatelessWidget {
  final String label;
  final String value;
  final VoidCallback onTap;

  const _TimeField({
    required this.label,
    required this.value,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey.withOpacity(0.5)),
        ),
        child: Row(
          children: [
            Text(label, style: const TextStyle(fontSize: 12)),
            const Spacer(),
            Text(
              value,
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }
}

// ===== 커스텀 타임 피커 =====
class _CustomTimePicker extends StatefulWidget {
  final CustomTime initial;

  const _CustomTimePicker({required this.initial});

  @override
  State<_CustomTimePicker> createState() => _CustomTimePickerState();
}

class _CustomTimePickerState extends State<_CustomTimePicker> {
  late int _minutes;
  late TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _minutes = widget.initial.totalMinutes;
    _controller = TextEditingController(text: _format(_minutes));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  String _format(int minutes) {
    if (minutes == 1440) return '24:00';
    final h = minutes ~/ 60;
    final m = minutes % 60;
    return '${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')}';
  }

  int? _parse(String input) {
    final text = input.trim();
    if (text.isEmpty) return null;

    if (text.contains(':')) {
      final parts = text.split(':');
      if (parts.length != 2) return null;

      final h = int.tryParse(parts[0]);
      final m = int.tryParse(parts[1]);
      if (h == null || m == null) return null;
      if (h < 0 || h > 24 || m < 0 || m > 59) return null;
      if (h == 24 && m != 0) return null;

      final total = h * 60 + m;
      return total.clamp(0, 1440) as int;
    }

    final digits = text.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.isEmpty) return null;

    int h, m;

    if (digits.length <= 2) {
      h = int.tryParse(digits) ?? 0;
      m = 0;
    } else {
      final val = int.tryParse(digits) ?? 0;
      h = val ~/ 100;
      m = val % 100;
    }

    if (h < 0 || h > 24 || m < 0 || m > 59) return null;
    if (h == 24 && m != 0) return null;

    final total = h * 60 + m;
    return total.clamp(0, 1440) as int;
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;

    return SafeArea(
      top: false,
      child: Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: bottom + 16,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '시간 선택',
              style: TextStyle(
                  fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Center(
              child: Text(
                _format(_minutes),
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 16),
            Slider(
              value: _minutes.toDouble(),
              min: 0,
              max: 1440,
              divisions: 144,
              label: _format(_minutes),
              onChanged: (v) {
                setState(() {
                  _minutes = v.round();
                  _controller.text = _format(_minutes);
                });
              },
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _controller,
              decoration: const InputDecoration(
                labelText: '시간 입력 (예: 0900, 0930, 09:00)',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
              onChanged: (value) {
                final parsed = _parse(value);
                if (parsed != null) {
                  setState(() {
                    _minutes = parsed;
                  });
                }
              },
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('취소'),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: () {
                    final parsed = _parse(_controller.text);
                    final finalMinutes = parsed ?? _minutes;
                    Navigator.of(context)
                        .pop(CustomTime(finalMinutes));
                  },
                  child: const Text('확인'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
