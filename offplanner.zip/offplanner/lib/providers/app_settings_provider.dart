// lib/providers/app_settings_provider.dart
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:offplanner/models/app_settings.dart';

class AppSettingsProvider extends ChangeNotifier {
  static const _prefsKey = 'app_settings';

  AppSettings _settings = const AppSettings();
  AppSettings get settings => _settings;

  bool _loaded = false; 
  bool get isLoaded => _loaded;

  AppSettingsProvider() {
    _loadFromPrefs();
  }

  Future<void> _loadFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonStr = prefs.getString(_prefsKey);

    if (jsonStr != null) {
      try {
        final map = json.decode(jsonStr) as Map<String, dynamic>;
        _settings = AppSettings.fromJson(map);
      } catch (_) {
      }
    }

    _loaded = true;
    notifyListeners();
  }

  Future<void> _saveToPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonStr = json.encode(_settings.toJson());
    await prefs.setString(_prefsKey, jsonStr);
  }


  void setNotificationsEnabled(bool value) {
    _settings = _settings.copyWith(notificationsEnabled: value);
    _saveToPrefs();
    notifyListeners();
  }

  void setVibrationEnabled(bool value) {
    _settings = _settings.copyWith(vibrationEnabled: value);
    _saveToPrefs();
    notifyListeners();
  }

  void setNotificationSound(String soundId) {
    _settings = _settings.copyWith(notificationSound: soundId);
    _saveToPrefs();
    notifyListeners();
  }

  void setVibrationMode(String mode) {
    _settings = _settings.copyWith(vibrationMode: mode);
    _saveToPrefs();
    notifyListeners();
  }

  void setTheme(String themeId) {
    _settings = _settings.copyWith(theme: themeId);
    _saveToPrefs();
    notifyListeners();
  }

  void setDefaultScheduleColor(String hex) {
    _settings = _settings.copyWith(defaultScheduleColorHex: hex);
    _saveToPrefs();
    notifyListeners();
  }

  void setDailyEnabled(bool value) {
    _settings = _settings.copyWith(dailyEnabled: value);
    _saveToPrefs();
    notifyListeners();
  }

  void setStartTabId(String id) {
    _settings = _settings.copyWith(startTabId: id);
    _saveToPrefs();
    notifyListeners();
  }

  List<String> getExitMessagesForBucket(String bucket) {
    switch (bucket) {
      case 'zero':
        return _settings.exitMsgZero;
      case 'low':
        return _settings.exitMsgLow;
      case 'mid':
        return _settings.exitMsgMid;
      case 'high':
        return _settings.exitMsgHigh;
      case 'perfect':
        return _settings.exitMsgPerfect;
      case 'noDaily':
        return _settings.exitMsgNoDaily;
      default:
        return const [];
    }
  }

  void _setBucket(String bucket, List<String> list) {
    switch (bucket) {
      case 'zero':
        _settings = _settings.copyWith(exitMsgZero: list);
        break;
      case 'low':
        _settings = _settings.copyWith(exitMsgLow: list);
        break;
      case 'mid':
        _settings = _settings.copyWith(exitMsgMid: list);
        break;
      case 'high':
        _settings = _settings.copyWith(exitMsgHigh: list);
        break;
      case 'perfect':
        _settings = _settings.copyWith(exitMsgPerfect: list);
        break;
      case 'noDaily':
        _settings = _settings.copyWith(exitMsgNoDaily: list);
        break;
      default:
        return;
    }
    _saveToPrefs();
    notifyListeners();
  }

  void addExitMessage(String bucket, String message) {
    final list = List<String>.from(getExitMessagesForBucket(bucket));
    list.add(message);
    _setBucket(bucket, list);
  }

  void updateExitMessage(String bucket, int index, String message) {
    final list = List<String>.from(getExitMessagesForBucket(bucket));
    if (index < 0 || index >= list.length) return;
    list[index] = message;
    _setBucket(bucket, list);
  }

  void removeExitMessage(String bucket, int index) {
    final list = List<String>.from(getExitMessagesForBucket(bucket));
    if (index < 0 || index >= list.length) return;
    list.removeAt(index);
    _setBucket(bucket, list);
  }


  String? backgroundImageForTab(String tabKey) {
    return _settings.backgroundImages[tabKey];
  }

  void setBackgroundImageForTab(String tabKey, String? base64) {
    final newMap = Map<String, String?>.from(_settings.backgroundImages);
    if (base64 == null) {
      newMap.remove(tabKey);
    } else {
      newMap[tabKey] = base64;
    }
    _settings = _settings.copyWith(backgroundImages: newMap);
    _saveToPrefs();
    notifyListeners();
  }

  double backgroundOpacityForTab(String tabKey) {
    return _settings.backgroundOpacity[tabKey] ?? 0.4;
  }

  void setBackgroundOpacityForTab(String tabKey, double value) {
    final newMap = Map<String, double>.from(_settings.backgroundOpacity);
    newMap[tabKey] = value;
    _settings = _settings.copyWith(backgroundOpacity: newMap);
    _saveToPrefs();
    notifyListeners();
  }

  double backgroundBlurForTab(String tabKey) {
    return _settings.backgroundBlur[tabKey] ?? 6.0;
  }

  void setBackgroundBlurForTab(String tabKey, double value) {
    final newMap = Map<String, double>.from(_settings.backgroundBlur);
    newMap[tabKey] = value;
    _settings = _settings.copyWith(backgroundBlur: newMap);
    _saveToPrefs();
    notifyListeners();
  }


  Future<void> resetSettings() async {
    _settings = const AppSettings();
    await _saveToPrefs();
    notifyListeners();
  }
}
