import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:offplanner/models/schedule_item.dart';
import 'package:offplanner/services/notification_service.dart';

class ScheduleProvider extends ChangeNotifier {
  static const String _storageKey = 'offplanner_schedules_v1';

  final List<ScheduleItem> _items = [];

  ScheduleProvider() {
    _loadFromPrefs();
  }

  // ================= 조회 =================

  List<ScheduleItem> get allItems => List.unmodifiable(_items);

  List<ScheduleItem> itemsForDate(DateTime date) {
    final y = date.year;
    final m = date.month;
    final d = date.day;

    final result = _items.where((item) {
      final id = item.date;
      return id.year == y && id.month == m && id.day == d;
    }).toList();

    result.sort((a, b) => a.start.totalMinutes.compareTo(b.start.totalMinutes));
    return result;
  }

  List<ScheduleItem> searchByKeyword(String keyword) {
    final q = keyword.trim().toLowerCase();
    if (q.isEmpty) return [];

    final result = _items.where((item) {
      return item.title.toLowerCase().contains(q) ||
          (item.memo?.toLowerCase().contains(q) ?? false);
    }).toList();

    result.sort((a, b) {
      final ad = DateTime(a.date.year, a.date.month, a.date.day);
      final bd = DateTime(b.date.year, b.date.month, b.date.day);
      final cmpDate = ad.compareTo(bd);
      if (cmpDate != 0) return cmpDate;
      return a.start.totalMinutes.compareTo(b.start.totalMinutes);
    });

    return result;
  }

  // ================= 내부 저장/불러오기 =================

  Future<void> _loadFromPrefs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final jsonStr = prefs.getString(_storageKey);
      if (jsonStr == null || jsonStr.isEmpty) return;

      final List<dynamic> data = jsonDecode(jsonStr);
      _items
        ..clear()
        ..addAll(data.map((e) => ScheduleItem.fromJson(e)));

      _sortItems();
      notifyListeners();
    } catch (e) {
      debugPrint('[ScheduleProvider] _loadFromPrefs error: $e');
    }
  }

  Future<void> _saveToPrefs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final data = _items.map((e) => e.toJson()).toList();
      await prefs.setString(_storageKey, jsonEncode(data));
    } catch (e) {
      debugPrint('[ScheduleProvider] _saveToPrefs error: $e');
    }
  }

  void _sortItems() {
    _items.sort((a, b) {
      final ad = DateTime(a.date.year, a.date.month, a.date.day);
      final bd = DateTime(b.date.year, b.date.month, b.date.day);
      final cmpDate = ad.compareTo(bd);
      if (cmpDate != 0) return cmpDate;
      return a.start.totalMinutes.compareTo(b.start.totalMinutes);
    });
  }

  // ================= 겹침 검사 =================

  void _checkOverlap(ScheduleItem newItem, {String? ignoreId}) {
    final newStart = newItem.start.totalMinutes;
    final newEnd = newItem.end.totalMinutes;

    final y = newItem.date.year;
    final m = newItem.date.month;
    final d = newItem.date.day;

    for (final e in _items) {
      if (e.id == ignoreId) continue;

      if (e.date.year == y && e.date.month == m && e.date.day == d) {
        final existStart = e.start.totalMinutes;
        final existEnd = e.end.totalMinutes;

        if (newStart < existEnd && newEnd > existStart) {
          throw Exception("이미 다른 일정과 시간이 겹칩니다.");
        }
      }
    }
  }

  // ================= 일정 추가/수정/삭제 =================

  Future<void> addSchedule(ScheduleItem item) async {
    _checkOverlap(item);

    _items.add(item);
    _sortItems();
    notifyListeners();

    await _saveToPrefs();
    await NotificationService().scheduleForScheduleItem(item);
  }

  Future<void> updateSchedule(ScheduleItem updated) async {
    _checkOverlap(updated, ignoreId: updated.id);

    final index = _items.indexWhere((e) => e.id == updated.id);
    if (index == -1) return;

    final old = _items[index];
    _items[index] = updated;
    _sortItems();
    notifyListeners();

    await _saveToPrefs();
    await NotificationService().cancelForScheduleItem(old);
    await NotificationService().scheduleForScheduleItem(updated);
  }

  Future<void> deleteSchedule(String id) async {
    final index = _items.indexWhere((e) => e.id == id);
    if (index == -1) return;

    final removed = _items.removeAt(index);
    notifyListeners();
    await _saveToPrefs();

    await NotificationService().cancelForScheduleItem(removed);
  }

  Future<void> clearAll() async {
    _items.clear();
    notifyListeners();
    await _saveToPrefs();
  }
}
