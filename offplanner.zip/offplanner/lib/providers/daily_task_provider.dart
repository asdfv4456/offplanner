// lib/providers/daily_task_provider.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DailyTask {
  final String id;
  final String title;
  final bool isDone;

  DailyTask({
    required this.id,
    required this.title,
    this.isDone = false,
  });

  DailyTask copyWith({String? title, bool? isDone}) {
    return DailyTask(
      id: id,
      title: title ?? this.title,
      isDone: isDone ?? this.isDone,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "title": title,
      "isDone": isDone,
    };
  }

  factory DailyTask.fromJson(Map<String, dynamic> json) {
    return DailyTask(
      id: json["id"],
      title: json["title"],
      isDone: json["isDone"] ?? false,
    );
  }
}

class DailyTaskProvider extends ChangeNotifier {
  final Map<String, List<DailyTask>> _tasks = {};

  String _dateKey(DateTime date) {
    return "${date.year}-${date.month}-${date.day}";
  }

  Future<void> loadFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString("daily_tasks");

    if (raw == null) return;

    final decoded = jsonDecode(raw) as Map<String, dynamic>;

    decoded.forEach((dateKey, listJson) {
      final list = (listJson as List)
          .map((e) => DailyTask.fromJson(e))
          .toList();
      _tasks[dateKey] = list;
    });

    notifyListeners();
  }

  Future<void> _saveToPrefs() async {
    final prefs = await SharedPreferences.getInstance();

    final encoded = jsonEncode(
      _tasks.map((key, value) =>
          MapEntry(key, value.map((e) => e.toJson()).toList())),
    );

    await prefs.setString("daily_tasks", encoded);
  }

  List<DailyTask> tasksForDate(DateTime date) {
    final key = _dateKey(date);
    return _tasks[key] ?? [];
  }

  void addTask(DateTime date, String title) {
    final key = _dateKey(date);
    final task = DailyTask(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      title: title,
    );

    if (_tasks[key] == null) _tasks[key] = [];
    _tasks[key]!.add(task);

    _saveToPrefs();
    notifyListeners();
  }

  void removeTask(DateTime date, String id) {
    final key = _dateKey(date);
    if (_tasks[key] == null) return;

    _tasks[key]!.removeWhere((t) => t.id == id);

    _saveToPrefs();
    notifyListeners();
  }

  void toggleTask(DateTime date, String id) {
    final key = _dateKey(date);
    if (_tasks[key] == null) return;

    _tasks[key] = _tasks[key]!.map((task) {
      if (task.id == id) {
        return task.copyWith(isDone: !task.isDone);
      }
      return task;
    }).toList();

    _saveToPrefs();
    notifyListeners();
  }


  double completionRate(DateTime date) {
    final list = tasksForDate(date);
    if (list.isEmpty) return 0.0;

    final doneCount = list.where((e) => e.isDone).length;
    return doneCount / list.length;
  }
}
