// lib/providers/dday_provider.dart
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:offplanner/models/dday_item.dart';
import 'package:offplanner/models/schedule_item.dart';

class DDayProvider extends ChangeNotifier {
  static const String _storageKey = 'offplanner_ddays_v1';

  final List<DDayItem> _items = [];

  DDayProvider() {
    _loadFromPrefs();
  }

  List<DDayItem> get allItems => List.unmodifiable(_items);

  List<DDayItem> upcoming({DateTime? from}) {
    final now = from ?? DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    final filtered = _items.where((d) {
      final target = DateTime(
        d.targetDate.year,
        d.targetDate.month,
        d.targetDate.day,
      );
      return d.isActive && !target.isBefore(today);
    }).toList();

    filtered.sort((a, b) => a.targetDate.compareTo(b.targetDate));
    return filtered;
  }

  int calcDiff(DateTime target, {DateTime? from}) {
    final now = from ?? DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final t = DateTime(target.year, target.month, target.day);
    return t.difference(today).inDays;
  }


  Future<void> _loadFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storageKey);
    if (raw == null || raw.isEmpty) return;

    try {
      final List decoded = jsonDecode(raw) as List;
      _items
        ..clear()
        ..addAll(
          decoded.map(
            (e) => DDayItem.fromJson(e as Map<String, dynamic>),
          ),
        );
      notifyListeners();
    } catch (e) {

    }
  }

  Future<void> _saveToPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final data = _items.map((e) => e.toJson()).toList();
    await prefs.setString(_storageKey, jsonEncode(data));
  }


  void addDDay(DDayItem item) {
    _items.add(item);
    notifyListeners();
    _saveToPrefs();
  }

  void updateDDay(DDayItem item) {
    final idx = _items.indexWhere((e) => e.id == item.id);
    if (idx == -1) return;
    _items[idx] = item;
    notifyListeners();
    _saveToPrefs();
  }

  void removeDDay(String id) {
    _items.removeWhere((e) => e.id == id);
    notifyListeners();
    _saveToPrefs();
  }

  void toggleActive(String id, bool isActive) {
    final idx = _items.indexWhere((e) => e.id == id);
    if (idx == -1) return;

    final old = _items[idx];
    _items[idx] = old.copyWith(isActive: isActive);
    notifyListeners();
    _saveToPrefs();
  }


  void clearAll() {
    _items.clear();
    notifyListeners();
    _saveToPrefs();
  }

  void createFromSchedule(ScheduleItem s) {
    final ddayId = 'from_schedule_${s.id}';
    final exists = _items.any((e) => e.id == ddayId);
    if (exists) return;

    final dday = DDayItem(
      id: ddayId,
      title: s.title,
      targetDate: DateTime(s.date.year, s.date.month, s.date.day),
      colorHex: s.colorHex,
    );

    _items.add(dday);
    notifyListeners();
    _saveToPrefs();
  }

  void removeByScheduleId(String scheduleId) {
    final ddayId = 'from_schedule_$scheduleId';
    _items.removeWhere((e) => e.id == ddayId);
    notifyListeners();
    _saveToPrefs();
  }
}
