// lib/main.dart
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:offplanner/providers/dday_provider.dart';
import 'package:offplanner/providers/schedule_provider.dart';
import 'package:offplanner/providers/selected_date_provider.dart';
import 'package:offplanner/providers/daily_task_provider.dart';
import 'package:offplanner/providers/app_settings_provider.dart';

import 'package:offplanner/services/notification_service.dart';
import 'package:offplanner/views/root_tab_page.dart';
import 'package:offplanner/views/alarm_ring_page.dart';


final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final notificationService = NotificationService();


  await notificationService.init();

  final launchDetails = await notificationService.getLaunchDetails();
  final launchedFromNotification =
      launchDetails?.didNotificationLaunchApp ?? false;
  final initialPayload = launchDetails?.notificationResponse?.payload;


  notificationService.setOnNotificationTap(_handleNotificationTap);

  runApp(
    OffPlannerApp(
      launchedFromNotification: launchedFromNotification,
      initialNotificationPayload: initialPayload,
    ),
  );
}


void _handleNotificationTap(String? payload) {
  String title = '알람';
  String body = '설정된 시간입니다.';

  if (payload != null && payload.isNotEmpty) {
    try {
      final data = jsonDecode(payload);
      if (data is Map) {
        if (data['title'] is String) {
          title = data['title'] as String;
        }
        if (data['body'] is String) {
          body = data['body'] as String;
        }
      }
    } catch (_) {

    }
  }

  try {
    navigatorKey.currentState?.push(
      MaterialPageRoute(
        builder: (_) => AlarmRingPage(
          title: title,
          body: body,
        ),
      ),
    );
  } catch (e) {
    debugPrint('❌ Navigator push error on notification tap: $e');
  }
}

class OffPlannerApp extends StatefulWidget {
  const OffPlannerApp({
    super.key,
    required this.launchedFromNotification,
    required this.initialNotificationPayload,
  });

  final bool launchedFromNotification;


  final String? initialNotificationPayload;

  @override
  State<OffPlannerApp> createState() => _OffPlannerAppState();
}

class _OffPlannerAppState extends State<OffPlannerApp> {
  @override
  void initState() {
    super.initState();

  
    if (widget.launchedFromNotification &&
        widget.initialNotificationPayload != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _handleNotificationTap(widget.initialNotificationPayload);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => SelectedDateProvider()),
        ChangeNotifierProvider(create: (_) => DDayProvider()),
        ChangeNotifierProvider(create: (_) => ScheduleProvider()),
        ChangeNotifierProvider(create: (_) => DailyTaskProvider()),
        ChangeNotifierProvider(create: (_) => AppSettingsProvider()),
      ],
      child: Consumer<AppSettingsProvider>(
        builder: (context, appSettingsProv, _) {
          final s = appSettingsProv.settings;

          return MaterialApp(
            title: 'OffPlanner',
            debugShowCheckedModeBanner: false,
            navigatorKey: navigatorKey,
            theme: _buildThemeFromId(s.theme),
            home: const RootTabPage(),
          );
        },
      ),
    );
  }

  ThemeData _buildThemeFromId(String id) {
    switch (id) {
      case 'dark':
        return ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: Colors.indigo,
            brightness: Brightness.dark,
          ),
          useMaterial3: true,
          textTheme: const TextTheme(
            bodyLarge: TextStyle(color: Colors.white),
            bodyMedium: TextStyle(color: Colors.white),
            bodySmall: TextStyle(color: Colors.white70),
            titleMedium: TextStyle(color: Colors.white),
            titleLarge: TextStyle(color: Colors.white),
          ),
          inputDecorationTheme: const InputDecorationTheme(
            labelStyle: TextStyle(color: Colors.white70),
            hintStyle: TextStyle(color: Colors.white38),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.white54),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.white),
            ),
          ),
          listTileTheme: const ListTileThemeData(
            textColor: Colors.white,
            iconColor: Colors.white,
          ),
        );

      case 'light':
        return ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: Colors.indigo,
            brightness: Brightness.light,
          ),
          useMaterial3: true,
        );

      case 'mint':
        return ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: Colors.teal,
            brightness: Brightness.light,
          ),
          useMaterial3: true,
        );

      case 'purple':
        return ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: Colors.deepPurple,
            brightness: Brightness.light,
          ),
          useMaterial3: true,
        );

      default:
        return ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: Colors.indigo,
            brightness: Brightness.light,
          ),
          useMaterial3: true,
        );
    }
  }
}
