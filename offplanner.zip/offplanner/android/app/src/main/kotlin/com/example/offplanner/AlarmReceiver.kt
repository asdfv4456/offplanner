package com.example.offplanner

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "알람"
        val body = intent.getStringExtra("body") ?: "설정된 시간입니다."
        val alarmId = intent.getIntExtra("alarmId", 0)

        Log.d("AlarmReceiver", "onReceive: id=$alarmId, title=$title")

        val activityIntent = Intent(context, AlarmRingActivity::class.java).apply {
            putExtra("title", title)
            putExtra("body", body)
            putExtra("alarmId", alarmId)
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP
            )
        }

        context.startActivity(activityIntent)
    }
}
