package com.example.offplanner

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log

object AlarmScheduler {

    private const val TAG = "AlarmScheduler"

 
    fun scheduleExact(
        context: Context,
        triggerAtMillis: Long,
        requestCode: Int,
        title: String,
        body: String
    ) {
        val alarmManager =
            context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("title", title)
            putExtra("body", body)
            putExtra("alarmId", requestCode)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        Log.d(TAG, " scheduleExact: at=$triggerAtMillis, id=$requestCode, title=$title")

        alarmManager.setExactAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            triggerAtMillis,
            pendingIntent
        )
    }

  
    fun scheduleSnooze(
        context: Context,
        requestCode: Int,
        title: String,
        body: String
    ) {
        val snoozeTime = System.currentTimeMillis() + 5 * 60 * 1000L
        scheduleExact(context, snoozeTime, requestCode, title, body)
    }

  
    fun cancel(
        context: Context,
        requestCode: Int
    ) {
        val alarmManager =
            context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val intent = Intent(context, AlarmReceiver::class.java)

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        Log.d(TAG, " cancel: id=$requestCode")

        alarmManager.cancel(pendingIntent)
    }
}
