package com.example.offplanner

import android.content.Context
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AlarmRingActivity : AppCompatActivity() {

    private var mediaPlayer: MediaPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var alarmId: Int = 0

    private lateinit var btnStop: Button
    private lateinit var btnSnooze: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.alarm_ring)


        turnScreenOnAndUnlock()

        val title = intent.getStringExtra("title") ?: "알람"
        val body = intent.getStringExtra("body") ?: "설정된 시간입니다."
        alarmId = intent.getIntExtra("alarmId", 0)

        val titleView = findViewById<TextView>(R.id.alarmTitle)
        val bodyView = findViewById<TextView>(R.id.alarmBody)
        btnStop = findViewById(R.id.btnStop)
        btnSnooze = findViewById(R.id.btnSnooze)

        titleView.text = title
        bodyView.text = body


        btnStop.setOnClickListener {
            finish()
        }


        btnSnooze.setOnClickListener {
            AlarmScheduler.scheduleSnooze(
                context = this,
                requestCode = alarmId,
                title = title,
                body = body
            )
            finish()
        }

        startAlarmSound()
    }

    override fun onDestroy() {
        stopAlarmSound()
        releaseWakeLock()
        super.onDestroy()
    }

    private fun startAlarmSound() {
        // raw/soft_alarm.mp3 사용
        mediaPlayer = MediaPlayer.create(this, R.raw.soft_alarm).apply {
            isLooping = true
            start()
        }
    }

    private fun stopAlarmSound() {
        mediaPlayer?.let { mp ->
            if (mp.isPlaying) {
                mp.stop()
            }
            mp.release()
        }
        mediaPlayer = null
    }

    private fun turnScreenOnAndUnlock() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setTurnScreenOn(true)
            setShowWhenLocked(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        @Suppress("DEPRECATION")
        wakeLock = pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                    PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "offplanner:alarmWakeLock"
        )
        wakeLock?.acquire(60_000) 
    }

    private fun releaseWakeLock() {
        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
        }
        wakeLock = null
    }
}
